<div class="theme-offer">
	<?php 
        // Check if the demo import has been completed
        $freelancer_services_demo_import_completed = get_option('freelancer_services_demo_import_completed', false);

        // If the demo import is completed, display the "View Site" button
        if ($freelancer_services_demo_import_completed) {
        echo '<p class="notice-text">' . esc_html__('Your demo import has been completed successfully.', 'freelancer-services') . '</p>';
        echo '<span><a href="' . esc_url(home_url()) . '" class="button button-primary site-btn" target="_blank">' . esc_html__('VIEW SITE', 'freelancer-services') . '</a></span>';
        }

		//POST and update the customizer and other related data
        if (isset($_POST['submit'])) {

            // ------- Create Nav Menu --------
            $freelancer_services_menuname = 'Main Menus';
            $freelancer_services_bpmenulocation = 'primary';
            $freelancer_services_menu_exists = wp_get_nav_menu_object($freelancer_services_menuname);

            if (!$freelancer_services_menu_exists) {
                $freelancer_services_menu_id = wp_create_nav_menu($freelancer_services_menuname);

                // Create Home Page
                $freelancer_services_home_title = 'Home';
                $freelancer_services_home = array(
                    'post_type' => 'page',
                    'post_title' => $freelancer_services_home_title,
                    'post_content' => '',
                    'post_status' => 'publish',
                    'post_author' => 1,
                    'post_slug' => 'home'
                );
                $freelancer_services_home_id = wp_insert_post($freelancer_services_home);
                // Assign Home Page Template
                add_post_meta($freelancer_services_home_id, '_wp_page_template', 'page-template/custom-home-page.php');
                // Update options to set Home Page as the front page
                update_option('page_on_front', $freelancer_services_home_id);
                update_option('show_on_front', 'page');
                // Add Home Page to Menu
                wp_update_nav_menu_item($freelancer_services_menu_id, 0, array(
                    'menu-item-title' => __('Home', 'freelancer-services'),
                    'menu-item-classes' => 'home',
                    'menu-item-url' => home_url('/'),
                    'menu-item-status' => 'publish',
                    'menu-item-object-id' => $freelancer_services_home_id,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type'
                ));

                // Create Pages Page with Dummy Content
                $freelancer_services_pages_title = 'Pages';
                $freelancer_services_pages_content = '
                <p>Explore all the pages we have on our website. Find information about our services, company, and more.</p>

                 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br> 

                  All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.';
                $freelancer_services_pages = array(
                    'post_type' => 'page',
                    'post_title' => $freelancer_services_pages_title,
                    'post_content' => $freelancer_services_pages_content,
                    'post_status' => 'publish',
                    'post_author' => 1,
                    'post_slug' => 'pages'
                );
                $freelancer_services_pages_id = wp_insert_post($freelancer_services_pages);
                // Add Pages Page to Menu
                wp_update_nav_menu_item($freelancer_services_menu_id, 0, array(
                    'menu-item-title' => __('Pages', 'freelancer-services'),
                    'menu-item-classes' => 'pages',
                    'menu-item-url' => home_url('/pages/'),
                    'menu-item-status' => 'publish',
                    'menu-item-object-id' => $freelancer_services_pages_id,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type'
                ));

                // Create About Us Page with Dummy Content
                $freelancer_services_about_title = 'About Us';
                $freelancer_services_about_content = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam...<br>

                         Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960 with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.<br> 

                            There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which dont look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isnt anything embarrassing hidden in the middle of text.<br> 

                            All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.';
                $freelancer_services_about = array(
                    'post_type' => 'page',
                    'post_title' => $freelancer_services_about_title,
                    'post_content' => $freelancer_services_about_content,
                    'post_status' => 'publish',
                    'post_author' => 1,
                    'post_slug' => 'about-us'
                );
                $freelancer_services_about_id = wp_insert_post($freelancer_services_about);
                // Add About Us Page to Menu
                wp_update_nav_menu_item($freelancer_services_menu_id, 0, array(
                    'menu-item-title' => __('About Us', 'freelancer-services'),
                    'menu-item-classes' => 'about-us',
                    'menu-item-url' => home_url('/about-us/'),
                    'menu-item-status' => 'publish',
                    'menu-item-object-id' => $freelancer_services_about_id,
                    'menu-item-object' => 'page',
                    'menu-item-type' => 'post_type'
                ));

                // Set the menu location if it's not already set
                if (!has_nav_menu($freelancer_services_bpmenulocation)) {
                    $locations = get_theme_mod('nav_menu_locations'); // Use 'nav_menu_locations' to get locations array
                    if (empty($locations)) {
                        $locations = array();
                    }
                    $locations[$freelancer_services_bpmenulocation] = $freelancer_services_menu_id;
                    set_theme_mod('nav_menu_locations', $locations);
                }               
        }

         
            // Set the demo import completion flag
    		update_option('freelancer_services_demo_import_completed', true);
    		// Display success message and "View Site" button
    		echo '<p class="notice-text">' . esc_html__('Your demo import has been completed successfully.', 'freelancer-services') . '</p>';
    		echo '<span><a href="' . esc_url(home_url()) . '" class="button button-primary site-btn" target="_blank">' . esc_html__('VIEW SITE', 'freelancer-services') . '</a></span>';
            //end 


            // Top Bar //
            set_theme_mod( 'freelancer_services_header_button_text', 'Get Started' );  
            set_theme_mod( 'freelancer_services_header_button_link', '#' );


            // slider section start //  

            for($freelancer_services_i=1;$freelancer_services_i<=3;$freelancer_services_i++){
               $freelancer_services_slider_title = 'We Have 1000+ Freelancer';
               $freelancer_services_slider_content = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500, when an unknown printer took a galley of type and scrambled it to make a type specimen book.';
                  // Create post object
               $my_post = array(
               'post_title'    => wp_strip_all_tags( $freelancer_services_slider_title ),
               'post_content'  => $freelancer_services_slider_content,
               'post_status'   => 'publish',
               'post_type'     => 'page',
               );

               // Insert the post into the database
               $freelancer_services_post_id = wp_insert_post( $my_post );

               if ($freelancer_services_post_id) {
                 // Set the theme mod for the slider page
                 set_theme_mod('freelancer_services_slider_page' . $freelancer_services_i, $freelancer_services_post_id);

                  $freelancer_services_image_url = get_template_directory_uri().'/assets/images/slider'.$freelancer_services_i.'.png';

                $freelancer_services_image_id = media_sideload_image($freelancer_services_image_url, $freelancer_services_post_id, null, 'id');

                    if (!is_wp_error($freelancer_services_image_id)) {
                        // Set the downloaded image as the post's featured image
                        set_post_thumbnail($freelancer_services_post_id, $freelancer_services_image_id);
                    }
                }
            }    
            

            //Service Settings //
            set_theme_mod( 'freelancer_services_section_title', 'Trending Services' );
            set_theme_mod( 'freelancer_services_section_text', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.' );
            set_theme_mod( 'freelancer_services_service_category', 'postcategory1');
 
            // Define post category names and post titles
            $freelancer_services_category_names = array('postcategory1', 'postcategory2');
            $freelancer_services_title_array = array(
                array("Website Link Building And Traffic Generator", "Generate Lead And Social Media Market", "Looking To The Hire An Digital Marketing Cha", "Looking To The Hire An Digital Marketing Cha"),
                array("Website Link Building And Traffic Generator", "Generate Lead And Social Media Market", "Looking To The Hire An Digital Marketing Cha", "Looking To The Hire An Digital Marketing Cha")
            );

            foreach ($freelancer_services_category_names as $freelancer_services_index => $freelancer_services_category_name) {
                // Create or retrieve the post category term ID
                $freelancer_services_term = term_exists($freelancer_services_category_name, 'category');
                if ($freelancer_services_term === 0 || $freelancer_services_term === null) {
                    // If the term does not exist, create it
                    $freelancer_services_term = wp_insert_term($freelancer_services_category_name, 'category');
                }
                if (is_wp_error($freelancer_services_term)) {
                    error_log('Error creating category: ' . $freelancer_services_term->get_error_message());
                    continue; // Skip to the next iteration if category creation fails
                }

                for ($freelancer_services_i = 0; $freelancer_services_i < 4; $freelancer_services_i++) {
                    // Create post content
                    $freelancer_services_title = $freelancer_services_title_array[$freelancer_services_index][$freelancer_services_i];
                    $freelancer_services_content = 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry standard dummy text ever since the 1500';

                    // Create post post object
                    $freelancer_services_my_post = array(
                        'post_title'    => wp_strip_all_tags($freelancer_services_title),
                        'post_content'  => $freelancer_services_content,
                        'post_status'   => 'publish',
                        'post_type'     => 'post', // Post type set to 'post'
                    );

                    // Insert the post into the database
                    $freelancer_services_post_id = wp_insert_post($freelancer_services_my_post);

                    update_post_meta($freelancer_services_post_id, 'freelancer_services_price', "$150");

                    if (is_wp_error($freelancer_services_post_id)) {
                        error_log('Error creating post: ' . $freelancer_services_post_id->get_error_message());
                        continue; // Skip to the next post if creation fails
                    }

                    // Assign the category to the post
                    wp_set_post_categories($freelancer_services_post_id, array((int)$freelancer_services_term['term_id']));

                    // Handle the featured image using media_sideload_image
                    $freelancer_services_image_url = get_template_directory_uri() . '/assets/images/service' . ($freelancer_services_i + 1) . '.png';
                    $freelancer_services_image_id = media_sideload_image($freelancer_services_image_url, $freelancer_services_post_id, null, 'id');

                    if (is_wp_error($freelancer_services_image_id)) {
                        error_log('Error downloading image: ' . $freelancer_services_image_id->get_error_message());
                        continue; // Skip to the next post if image download fails
                    }
                    // Assign featured image to post
                    set_post_thumbnail($freelancer_services_post_id, $freelancer_services_image_id);
                }
            } 


            //Copyright Text
            set_theme_mod( 'freelancer_services_footer_text', 'By VWThemes' );  
     
        }
    ?>


    <p><?php esc_html_e('Please back up your website if it’s already live with data. This importer will overwrite your existing settings with the new customizer values for Freelancer Services', 'freelancer-services'); ?></p>
    <form action="<?php echo esc_url(home_url()); ?>/wp-admin/themes.php?page=freelancer_services_guide" method="POST" onsubmit="return validate(this);">
        <?php if (!get_option('freelancer_services_demo_import_completed')) : ?>
            <input class="run-import" type="submit" name="submit" value="<?php esc_attr_e('Run Importer', 'freelancer-services'); ?>" class="button button-primary button-large">
        <?php endif; ?>
        <div id="spinner" style="display:none;">         
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/spinner.png" alt="" />
        </div>
    </form>
    <script type="text/javascript">
        function validate(form) {
            if (confirm("Do you really want to import the theme demo content?")) {
                // Show the spinner
                document.getElementById('spinner').style.display = 'block';
                // Allow the form to be submitted
                return true;
            } 
            else {
                return false;
            }
        }
    </script>
</div>

