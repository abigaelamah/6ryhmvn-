<?php
/**
 * Freelancer Services Theme Customizer
 *
 * @package Freelancer Services
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */

function freelancer_services_custom_controls() {
	load_template( trailingslashit( get_template_directory() ) . '/inc/custom-controls.php' );
}
add_action( 'customize_register', 'freelancer_services_custom_controls' );

function freelancer_services_customize_register( $wp_customize ) {

	load_template( trailingslashit( get_template_directory() ) . '/inc/icon-picker.php' );

	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage'; 
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial( 'blogname', array( 
		'selector' => '.logo .site-title a', 
	 	'render_callback' => 'freelancer_services_Customize_partial_blogname',
	)); 

	$wp_customize->selective_refresh->add_partial( 'blogdescription', array( 
		'selector' => 'p.site-description', 
		'render_callback' => 'freelancer_services_Customize_partial_blogdescription',
	));

	//Homepage Settings
	$wp_customize->add_panel( 'freelancer_services_homepage_panel', array(
		'title' => esc_html__( 'Homepage Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_panel_id',
		'priority' => 20,
	));

	// Top Bar
	$wp_customize->add_section( 'freelancer_services_header' , array(
    	'title' => esc_html__( 'Header', 'freelancer-services' ),
		'panel' => 'freelancer_services_homepage_panel'
	) );

	//Sticky Header
	$wp_customize->add_setting( 'freelancer_services_sticky_header',array(
	    'default' => 0,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
  	) );
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_sticky_header',array(
	    'label' => esc_html__( 'Sticky Header','freelancer-services' ),
	    'section' => 'freelancer_services_header'
  	)));

   	// Header Background color
	$wp_customize->add_setting('freelancer_services_header_background_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_header_background_color', array(
		'label'    => __('Header Background Color', 'freelancer-services'),
		'section'  => 'freelancer_services_header',
	)));

	$wp_customize->add_setting('freelancer_services_header_img_position',array(
	  'default' => 'center top',
	  'transport' => 'refresh',
	  'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_header_img_position',array(
		'type' => 'select',
		'label' => __('Header Image Position','freelancer-services'),
		'section' => 'freelancer_services_header',
		'choices' 	=> array(
			'left top' 		=> esc_html__( 'Top Left', 'freelancer-services' ),
			'center top'   => esc_html__( 'Top', 'freelancer-services' ),
			'right top'   => esc_html__( 'Top Right', 'freelancer-services' ),
			'left center'   => esc_html__( 'Left', 'freelancer-services' ),
			'center center'   => esc_html__( 'Center', 'freelancer-services' ),
			'right center'   => esc_html__( 'Right', 'freelancer-services' ),
			'left bottom'   => esc_html__( 'Bottom Left', 'freelancer-services' ),
			'center bottom'   => esc_html__( 'Bottom', 'freelancer-services' ),
			'right bottom'   => esc_html__( 'Bottom Right', 'freelancer-services' ),
		), 
	));

	$wp_customize->add_setting('freelancer_services_header_button_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_header_button_text',array(
		'label'	=> esc_html__('Add Button Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Get Started', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_header',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_header_button_link',array(
		'default'=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));
	$wp_customize->add_control('freelancer_services_header_button_link',array(
		'label'	=> esc_html__('Add Button Link','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'www.example.com', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_header',
		'type'=> 'text'
	));

	//Menus Settings
	$wp_customize->add_section( 'freelancer_services_menu_section' , array(
    	'title' => __( 'Menus Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_homepage_panel'
	) );

	$wp_customize->add_setting('freelancer_services_navigation_menu_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_navigation_menu_font_size',array(
		'label'	=> __('Menus Font Size','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_menu_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_navigation_menu_font_weight',array(
        'default' => 500,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_navigation_menu_font_weight',array(
        'type' => 'select',
        'label' => __('Menus Font Weight','freelancer-services'),
        'section' => 'freelancer_services_menu_section',
        'choices' => array(
        	'100' => __('100','freelancer-services'),
            '200' => __('200','freelancer-services'),
            '300' => __('300','freelancer-services'),
            '400' => __('400','freelancer-services'),
            '500' => __('500','freelancer-services'),
            '600' => __('600','freelancer-services'),
            '700' => __('700','freelancer-services'),
            '800' => __('800','freelancer-services'),
            '900' => __('900','freelancer-services'),
        ),
	) );

	// text trasform
	$wp_customize->add_setting('freelancer_services_menu_text_transform',array(
		'default'=> 'Capitalize',
		'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_menu_text_transform',array(
		'type' => 'radio',
		'label'	=> __('Menus Text Transform','freelancer-services'),
		'choices' => array(
            'Uppercase' => __('Uppercase','freelancer-services'),
            'Capitalize' => __('Capitalize','freelancer-services'),
            'Lowercase' => __('Lowercase','freelancer-services'),
        ),
		'section'=> 'freelancer_services_menu_section',
	));

	$wp_customize->add_setting('freelancer_services_menus_item_style',array(
        'default' => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_menus_item_style',array(
        'type' => 'select',
        'section' => 'freelancer_services_menu_section',
		'label' => __('Menu Item Hover Style','freelancer-services'),
		'choices' => array(
            'None' => __('None','freelancer-services'),
            'Zoom In' => __('Zoom In','freelancer-services'),
        ),
	) );

	$wp_customize->add_setting('freelancer_services_header_menus_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_header_menus_color', array(
		'label'    => __('Menus Color', 'freelancer-services'),
		'section'  => 'freelancer_services_menu_section',
	)));

	$wp_customize->add_setting('freelancer_services_header_menus_hover_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_header_menus_hover_color', array(
		'label'    => __('Menus Hover Color', 'freelancer-services'),
		'section'  => 'freelancer_services_menu_section',
	)));

	$wp_customize->add_setting('freelancer_services_header_submenus_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_header_submenus_color', array(
		'label'    => __('Sub Menus Color', 'freelancer-services'),
		'section'  => 'freelancer_services_menu_section',
	)));

	$wp_customize->add_setting('freelancer_services_header_submenus_hover_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_header_submenus_hover_color', array(
		'label'    => __('Sub Menus Hover Color', 'freelancer-services'),
		'section'  => 'freelancer_services_menu_section',
	)));

	//Slider
	$wp_customize->add_section( 'freelancer_services_slidersettings' , array(
		'title'      => __( 'Slider Settings', 'freelancer-services' ),
		'description' => __('Free theme has 3 slides options, For unlimited slides and more options </br> <a class="go-pro-btn" target="blank" href="https://www.vwthemes.com/products/freelancer-wordpress-theme">GET PRO</a>','freelancer-services'),
		'panel' => 'freelancer_services_homepage_panel'
	) );

	$wp_customize->add_setting( 'freelancer_services_slider_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));  
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_slider_hide_show',array(
      'label' => esc_html__( 'Show / Hide Slider','freelancer-services' ),
      'section' => 'freelancer_services_slidersettings'
    )));

    $wp_customize->add_setting('freelancer_services_slider_type',array(
        'default' => 'Default slider',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	) );
	$wp_customize->add_control('freelancer_services_slider_type', array(
        'type' => 'select',
        'label' => __('Slider Type','freelancer-services'),
        'section' => 'freelancer_services_slidersettings',
        'choices' => array(
            'Default slider' => __('Default slider','freelancer-services'),
            'Advance slider' => __('Advance slider','freelancer-services'),
        ),
	));

	$wp_customize->add_setting('freelancer_services_advance_slider_shortcode',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_advance_slider_shortcode',array(
		'label'	=> __('Add Slider Shortcode','freelancer-services'),
		'section'=> 'freelancer_services_slidersettings',
		'type'=> 'text',
		'active_callback' => 'freelancer_services_advance_slider'
	));

    //Selective Refresh
    $wp_customize->selective_refresh->add_partial('freelancer_services_slider_hide_show',array(
		'selector'        => '.slider-btn a',
		'render_callback' => 'freelancer_services_customize_partial_freelancer_services_slider_hide_show',
	));

	for ( $count = 1; $count <= 3; $count++ ) {
		$wp_customize->add_setting( 'freelancer_services_slider_page' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'freelancer_services_sanitize_dropdown_pages'
		) );
		$wp_customize->add_control( 'freelancer_services_slider_page' . $count, array(
			'label'    => __( 'Select Slider Page', 'freelancer-services' ),
			'description' => __('Slider image size (1500 x 600)','freelancer-services'),
			'section'  => 'freelancer_services_slidersettings',
			'type'     => 'dropdown-pages',
			'active_callback' => 'freelancer_services_default_slider'
		) );
	}

	$wp_customize->add_setting( 'freelancer_services_slider_content_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));  
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_slider_content_hide_show',array(
		'label' => esc_html__( 'Show / Hide Slider Content','freelancer-services' ),
		'section' => 'freelancer_services_slidersettings',
		'active_callback' => 'freelancer_services_default_slider'
    )));

	//content layout
	$wp_customize->add_setting('freelancer_services_slider_content_option',array(
        'default' => 'Left',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control(new Freelancer_Services_Image_Radio_Control($wp_customize, 'freelancer_services_slider_content_option', array(
        'type' => 'select',
        'label' => __('Slider Content Layouts','freelancer-services'),
        'section' => 'freelancer_services_slidersettings',
        'choices' => array(
            'Left' => esc_url(get_template_directory_uri()).'/assets/images/slider-content1.png',
            'Center' => esc_url(get_template_directory_uri()).'/assets/images/slider-content2.png',
            'Right' => esc_url(get_template_directory_uri()).'/assets/images/slider-content3.png',
    ),'active_callback' => 'freelancer_services_default_slider'
    )));

    //Slider excerpt
	$wp_customize->add_setting( 'freelancer_services_slider_excerpt_number', array(
		'default'              => 30,
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_slider_excerpt_number', array(
		'label'       => esc_html__( 'Slider Excerpt length','freelancer-services' ),
		'section'     => 'freelancer_services_slidersettings',
		'type'        => 'range',
		'settings'    => 'freelancer_services_slider_excerpt_number',
		'input_attrs' => array(
			'step'             => 5,
			'min'              => 0,
			'max'              => 50,
		),'active_callback' => 'freelancer_services_default_slider'
	) );

	//Slider height
	$wp_customize->add_setting('freelancer_services_slider_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_slider_height',array(
		'label'	=> __('Slider Height','freelancer-services'),
		'description'	=> __('Specify the slider height (px).','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '500px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_slidersettings',
		'type'=> 'text',
		'active_callback' => 'freelancer_services_default_slider'
	));

	$wp_customize->add_setting( 'freelancer_services_slider_speed', array(
		'default'  => 4000,
		'sanitize_callback'	=> 'sanitize_text_field'
	) );
	$wp_customize->add_control( 'freelancer_services_slider_speed', array(
		'label' => esc_html__('Slider Transition Speed','freelancer-services'),
		'section' => 'freelancer_services_slidersettings',
		'type'  => 'text',
		'active_callback' => 'freelancer_services_default_slider'
	) );

	//Opacity
	$wp_customize->add_setting('freelancer_services_slider_opacity_color',array(
		'default'              => 0.7,
		'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));

	$wp_customize->add_control( 'freelancer_services_slider_opacity_color', array(
		'label'       => esc_html__( 'Slider Image Opacity','freelancer-services' ),
		'section'     => 'freelancer_services_slidersettings',
		'type'        => 'select',
		'settings'    => 'freelancer_services_slider_opacity_color',
		'choices' => array(
			'0' =>  esc_attr(__('0','freelancer-services')),
			'0.1' =>  esc_attr(__('0.1','freelancer-services')),
			'0.2' =>  esc_attr(__('0.2','freelancer-services')),
			'0.3' =>  esc_attr(__('0.3','freelancer-services')),
			'0.4' =>  esc_attr(__('0.4','freelancer-services')),
			'0.5' =>  esc_attr(__('0.5','freelancer-services')),
			'0.6' =>  esc_attr(__('0.6','freelancer-services')),
			'0.7' =>  esc_attr(__('0.7','freelancer-services')),
			'0.8' =>  esc_attr(__('0.8','freelancer-services')),
			'0.9' =>  esc_attr(__('0.9','freelancer-services'))
		),'active_callback' => 'freelancer_services_default_slider'
	));

	$wp_customize->add_setting( 'freelancer_services_slider_image_overlay',array(
    	'default' => 1,
      	'transport' => 'refresh',
      	'sanitize_callback' => 'freelancer_services_switch_sanitization'
   	));
   	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_slider_image_overlay',array(
      	'label' => esc_html__( 'Show / Hide Slider Image Overlay','freelancer-services' ),
      	'section' => 'freelancer_services_slidersettings',
      	'active_callback' => 'freelancer_services_default_slider'
   )));

   	$wp_customize->add_setting('freelancer_services_slider_image_overlay_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_slider_image_overlay_color', array(
		'label'    => __('Slider Image Overlay Color', 'freelancer-services'),
		'section'  => 'freelancer_services_slidersettings',
		'active_callback' => 'freelancer_services_default_slider'
	)));

	$wp_customize->add_setting( 'freelancer_services_slider_arrow_hide_show',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_slider_arrow_hide_show',array(
		'label' => esc_html__( 'Show / Hide Slider Arrows','freelancer-services' ),
		'section' => 'freelancer_services_slidersettings',
		'active_callback' => 'freelancer_services_default_slider'
	)));

	$wp_customize->add_setting('freelancer_services_slider_prev_icon',array(
		'default'	=> 'fas fa-angle-left',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_slider_prev_icon',array(
		'label'	=> __('Add Slider Prev Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_slidersettings',
		'setting'	=> 'freelancer_services_slider_prev_icon',
		'type'		=> 'icon',
		'active_callback' => 'freelancer_services_default_slider'
	)));

	$wp_customize->add_setting('freelancer_services_slider_next_icon',array(
		'default'	=> 'fas fa-angle-right',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_slider_next_icon',array(
		'label'	=> __('Add Slider Next Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_slidersettings',
		'setting'	=> 'freelancer_services_slider_next_icon',
		'type'		=> 'icon',
		'active_callback' => 'freelancer_services_default_slider'
	)));

	//Experiences Section
	$wp_customize->add_section('freelancer_services_experiences_section', array(
		'title'       => __('Experiences Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_experiences_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_experiences_text',array(
		'description' => __('<p>1. More options for experiences section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for experiences section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_experiences_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_experiences_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_experiences_btn',array(	
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_experiences_section',
		'type'=> 'hidden'
	));

	//counter Section
	$wp_customize->add_section('freelancer_services_counter_section', array(
		'title'       => __('Counter Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_counter_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_counter_text',array(
		'description' => __('<p>1. More options for counter section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for counter section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_counter_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_counter_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_counter_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_counter_section',
		'type'=> 'hidden'
	));

	//category Section
	$wp_customize->add_section('freelancer_services_category_section', array(
		'title'       => __('Category Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_category_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_category_text',array(
		'description' => __('<p>1. More options for category section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for category section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_category_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_category_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_category_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_category_section',
		'type'=> 'hidden'
	));

	//Portfolios Section
	$wp_customize->add_section('freelancer_services_portfolios_section', array(
		'title'       => __('Portfolio Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_portfolios_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_portfolios_text',array(
		'description' => __('<p>1. More options for portfolio section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for portfolio section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_portfolios_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_portfolios_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_portfolios_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_portfolios_section',
		'type'=> 'hidden'
	));

	// About Section
	$wp_customize->add_section('freelancer_services_services_section',array(
		'title'	=> __('Services Section','freelancer-services'),
		'description' => __('For more options of the services section </br> <a class="go-pro-btn" target="blank" href="https://www.vwthemes.com/products/freelancer-wordpress-theme">GET PRO</a>','freelancer-services'),
		'panel' => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting( 'freelancer_services_section_title', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	$wp_customize->add_control( 'freelancer_services_section_title', array(
		'label'    => __( 'Add Section Title', 'freelancer-services' ),
		'input_attrs' => array(
            'placeholder' => __( 'Trending Services', 'freelancer-services' ),
        ),
		'section'  => 'freelancer_services_services_section',
		'type'     => 'text'
	) );

	$wp_customize->add_setting( 'freelancer_services_section_text', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	$wp_customize->add_control( 'freelancer_services_section_text', array(
		'label'    => __( 'Add Section Text', 'freelancer-services' ),
		'input_attrs' => array(
            'placeholder' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'freelancer-services' ),
        ),
		'section'  => 'freelancer_services_services_section',
		'type'     => 'text'
	) );

	$categories = get_categories();
		$cat_posts = array();
			$i = 0;
			$cat_posts[]='Select';
		foreach($categories as $category){
			if($i==0){
			$default = $category->slug;
			$i++;
		}
		$cat_posts[$category->slug] = $category->name;
	}

	$wp_customize->add_setting('freelancer_services_service_category',array(
		'default'	=> 'select',
		'sanitize_callback' => 'freelancer_services_sanitize_choices',
	));
	$wp_customize->add_control('freelancer_services_service_category',array(
		'type'    => 'select',
		'choices' => $cat_posts,
		'label' => __('Select Category to display Services','freelancer-services'),
		'section' => 'freelancer_services_services_section',
	));

	//keypoint Section
	$wp_customize->add_section('freelancer_services_keypoint_section', array(
		'title'       => __('Keypoint Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_keypoint_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_keypoint_text',array(
		'description' => __('<p>1. More options for keypoint section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for keypoint section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_keypoint_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_keypoint_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_keypoint_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_keypoint_section',
		'type'=> 'hidden'
	));

	//Freelancers Section
	$wp_customize->add_section('freelancer_services_freelancers_section', array(
		'title'       => __('Freelancers Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_freelancers_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_freelancers_text',array(
		'description' => __('<p>1. More options for freelancers section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for freelancers section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_freelancers_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_freelancers_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_freelancers_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_freelancers_section',
		'type'=> 'hidden'
	));

	//features Section
	$wp_customize->add_section('freelancer_services_features_section', array(
		'title'       => __('Features Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_features_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_features_text',array(
		'description' => __('<p>1. More options for features section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for features section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_features_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_features_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_features_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_features_section',
		'type'=> 'hidden'
	));

	//pricing card Section
	$wp_customize->add_section('freelancer_services_pricing_card_section', array(
		'title'       => __('Pricing Card Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_pricing_card_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_pricing_card_text',array(
		'description' => __('<p>1. More options for pricing card section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for pricing card section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_pricing_card_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_pricing_card_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_pricing_card_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_pricing_card_section',
		'type'=> 'hidden'
	));

	//team Section
	$wp_customize->add_section('freelancer_services_team_section', array(
		'title'       => __('Team Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_team_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_team_text',array(
		'description' => __('<p>1. More options for team section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for team section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_team_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_team_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_team_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_team_section',
		'type'=> 'hidden'
	));

	//Testimonial Section
	$wp_customize->add_section('freelancer_services_testimonial_section', array(
		'title'       => __('Testimonial Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_testimonial_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_testimonial_text',array(
		'description' => __('<p>1. More options for testimonial section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for testimonial section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_testimonial_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_testimonial_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_testimonial_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_testimonial_section',
		'type'=> 'hidden'
	));

	//latest post Section
	$wp_customize->add_section('freelancer_services_latest_post_section', array(
		'title'       => __('Latest Post Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_latest_post_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_latest_post_text',array(
		'description' => __('<p>1. More options for latest post section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for latest post section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_latest_post_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_latest_post_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_latest_post_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_latest_post_section',
		'type'=> 'hidden'
	));

	//partners Section
	$wp_customize->add_section('freelancer_services_partners_section', array(
		'title'       => __('Partners Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_partners_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_partners_text',array(
		'description' => __('<p>1. More options for partners section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for partners section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_partners_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_partners_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_partners_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_partners_section',
		'type'=> 'hidden'
	));

	//get started Section
	$wp_customize->add_section('freelancer_services_get_started_section', array(
		'title'       => __('Get Started Section', 'freelancer-services'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','freelancer-services'),
		'priority'    => null,
		'panel'       => 'freelancer_services_homepage_panel',
	));

	$wp_customize->add_setting('freelancer_services_get_started_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_get_started_text',array(
		'description' => __('<p>1. More options for get started section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for get started section.</p>','freelancer-services'),
		'section'=> 'freelancer_services_get_started_section',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('freelancer_services_get_started_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_get_started_btn',array(
		'description' => "<a class='go-pro' target='_blank' href=".esc_url(FREELANCER_SERVICES_BUY_NOW).">More Info</a>",
		'section'=> 'freelancer_services_get_started_section',
		'type'=> 'hidden'
	));

	//Footer Text
	$wp_customize->add_section('freelancer_services_footer',array(
		'title'	=> esc_html__('Footer Settings','freelancer-services'),
		'description' => __('For more options of the footer section </br> <a class="go-pro-btn" target="blank" href="https://www.vwthemes.com/products/freelancer-wordpress-theme">GET PRO</a>','freelancer-services'),
		'panel' => 'freelancer_services_homepage_panel',
	));	

	$wp_customize->add_setting( 'freelancer_services_footer_hide_show',array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_footer_hide_show',array(
      'label' => esc_html__( 'Show / Hide Footer','freelancer-services' ),
      'section' => 'freelancer_services_footer'
    )));

 	// font size
	$wp_customize->add_setting('freelancer_services_button_footer_font_size',array(
		'default'=> 25,
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_footer_font_size',array(
		'label'	=> __('Footer Heading Font Size','freelancer-services'),
  		'type'        => 'number',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
		'section'=> 'freelancer_services_footer',
	));

	$wp_customize->add_setting('freelancer_services_button_footer_heading_letter_spacing',array(
		'default'=> 1,
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_footer_heading_letter_spacing',array(
		'label'	=> __('Heading Letter Spacing','freelancer-services'),
  		'type'        => 'number',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
	),
		'section'=> 'freelancer_services_footer',
	));

	// text trasform
	$wp_customize->add_setting('freelancer_services_button_footer_text_transform',array(
		'default'=> 'Capitalize',
		'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_button_footer_text_transform',array(
		'type' => 'radio',
		'label'	=> __('Heading Text Transform','freelancer-services'),
		'choices' => array(
      'Uppercase' => __('Uppercase','freelancer-services'),
      'Capitalize' => __('Capitalize','freelancer-services'),
      'Lowercase' => __('Lowercase','freelancer-services'),
    ),
		'section'=> 'freelancer_services_footer',
	));

	$wp_customize->add_setting('freelancer_services_footer_heading_weight',array(
        'default' => 600,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_footer_heading_weight',array(
        'type' => 'select',
        'label' => __('Heading Font Weight','freelancer-services'),
        'section' => 'freelancer_services_footer',
        'choices' => array(
        	'100' => __('100','freelancer-services'),
            '200' => __('200','freelancer-services'),
            '300' => __('300','freelancer-services'),
            '400' => __('400','freelancer-services'),
            '500' => __('500','freelancer-services'),
            '600' => __('600','freelancer-services'),
            '700' => __('700','freelancer-services'),
            '800' => __('800','freelancer-services'),
            '900' => __('900','freelancer-services'),
        ),
	) );

	$wp_customize->add_setting('freelancer_services_footer_template',array(
		'default'	=> esc_html('freelancer_services-footer-one'),
		'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_footer_template',array(
		'label'	=> esc_html__('Footer style','freelancer-services'),
		'section'	=> 'freelancer_services_footer',
		'setting'	=> 'freelancer_services_footer_template',
		'type' => 'select',
		'choices' => array(
			'freelancer_services-footer-one' => esc_html__('Style 1', 'freelancer-services'),
			'freelancer_services-footer-two' => esc_html__('Style 2', 'freelancer-services'),
			'freelancer_services-footer-three' => esc_html__('Style 3', 'freelancer-services'),
			'freelancer_services-footer-four' => esc_html__('Style 4', 'freelancer-services'),
			'freelancer_services-footer-five' => esc_html__('Style 5', 'freelancer-services'),
		)
	));

	$wp_customize->add_setting('freelancer_services_footer_background_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_footer_background_color', array(
		'label'    => __('Footer Background Color', 'freelancer-services'),
		'section'  => 'freelancer_services_footer',
	)));

	$wp_customize->add_setting('freelancer_services_footer_background_image',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw',
	));
	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize,'freelancer_services_footer_background_image',array(
        'label' => __('Footer Background Image','freelancer-services'),
        'section' => 'freelancer_services_footer'
	)));

	$wp_customize->add_setting('freelancer_services_footer_img_position',array(
	  'default' => 'center center',
	  'transport' => 'refresh',
	  'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_footer_img_position',array(
		'type' => 'select',
		'label' => __('Footer Image Position','freelancer-services'),
		'section' => 'freelancer_services_footer',
		'choices' 	=> array(
			'left top' 		=> esc_html__( 'Top Left', 'freelancer-services' ),
			'center top'   => esc_html__( 'Top', 'freelancer-services' ),
			'right top'   => esc_html__( 'Top Right', 'freelancer-services' ),
			'left center'   => esc_html__( 'Left', 'freelancer-services' ),
			'center center'   => esc_html__( 'Center', 'freelancer-services' ),
			'right center'   => esc_html__( 'Right', 'freelancer-services' ),
			'left bottom'   => esc_html__( 'Bottom Left', 'freelancer-services' ),
			'center bottom'   => esc_html__( 'Bottom', 'freelancer-services' ),
			'right bottom'   => esc_html__( 'Bottom Right', 'freelancer-services' ),
		),
	)); 

	// Footer
	$wp_customize->add_setting('freelancer_services_img_footer',array(
		'default'=> 'scroll',
		'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_img_footer',array(
		'type' => 'select',
		'label'	=> __('Footer Background Attatchment','freelancer-services'),
		'choices' => array(
            'fixed' => __('fixed','freelancer-services'),
            'scroll' => __('scroll','freelancer-services'),
        ),
		'section'=> 'freelancer_services_footer',
	));

	$wp_customize->add_setting('freelancer_services_footer_widgets_heading',array(
    'default' => 'Left',
    'transport' => 'refresh',
    'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_footer_widgets_heading',array(
    'type' => 'select',
    'label' => __('Footer Widget Heading','freelancer-services'),
    'section' => 'freelancer_services_footer',
    'choices' => array(
    	'Left' => __('Left','freelancer-services'),
        'Center' => __('Center','freelancer-services'),
        'Right' => __('Right','freelancer-services')
    ),
	) );

	$wp_customize->add_setting('freelancer_services_footer_widgets_content',array(
    'default' => 'Left',
    'transport' => 'refresh',
    'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_footer_widgets_content',array(
    'type' => 'select',
    'label' => __('Footer Widget Content','freelancer-services'),
    'section' => 'freelancer_services_footer',
    'choices' => array(
    	'Left' => __('Left','freelancer-services'),
        'Center' => __('Center','freelancer-services'),
        'Right' => __('Right','freelancer-services')
    ),
	) );

	// footer padding
	$wp_customize->add_setting('freelancer_services_footer_padding',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_footer_padding',array(
		'label'	=> __('Footer Top Bottom Padding','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
      'placeholder' => __( '10px', 'freelancer-services' ),
    ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

    // footer social icon
  	$wp_customize->add_setting( 'freelancer_services_footer_icon',array(
		'default' => false,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_footer_icon',array(
		'label' => esc_html__( 'Show / Hide Footer Social Icon','freelancer-services' ),
		'section' => 'freelancer_services_footer'
    ))); 

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('freelancer_services_footer_text', array( 
		'selector' => '.copyright p', 
		'render_callback' => 'freelancer_services_Customize_partial_freelancer_services_footer_text', 
	));
	
	$wp_customize->add_setting( 'freelancer_services_copyright_hide_show',array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_copyright_hide_show',array(
      'label' => esc_html__( 'Show / Hide Copyright','freelancer-services' ),
      'section' => 'freelancer_services_footer'
    )));

	$wp_customize->add_setting('freelancer_services_copyright_background_color', array(
		'default'           => '#6102d3',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_copyright_background_color', array(
		'label'    => __('Copyright Background Color', 'freelancer-services'),
		'section'  => 'freelancer_services_footer',
	)));

	$wp_customize->add_setting('freelancer_services_copyright_text_color', array(
		'default'           => '#fff',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_copyright_text_color', array(
		'label'    => __('Copyright Text Color', 'freelancer-services'),
		'section'  => 'freelancer_services_footer',
	)));
	
	$wp_customize->add_setting('freelancer_services_footer_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('freelancer_services_footer_text',array(
		'label'	=> esc_html__('Copyright Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Copyright 2021, .....', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_copyright_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_copyright_font_size',array(
		'label'	=> __('Copyright Font Size','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_copyright_font_weight',array(
	  'default' => 400,
	  'transport' => 'refresh',
	  'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_copyright_font_weight',array(
	    'type' => 'select',
	    'label' => __('Copyright Font Weight','freelancer-services'),
	    'section' => 'freelancer_services_footer',
	    'choices' => array(
	    	'100' => __('100','freelancer-services'),
	        '200' => __('200','freelancer-services'),
	        '300' => __('300','freelancer-services'),
	        '400' => __('400','freelancer-services'),
	        '500' => __('500','freelancer-services'),
	        '600' => __('600','freelancer-services'),
	        '700' => __('700','freelancer-services'),
	        '800' => __('800','freelancer-services'),
	        '900' => __('900','freelancer-services'),
    ),
	));

	$wp_customize->add_setting('freelancer_services_copyright_alingment',array(
        'default' => 'center',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control(new Freelancer_Services_Image_Radio_Control($wp_customize, 'freelancer_services_copyright_alingment', array(
        'type' => 'select',
        'label' => esc_html__('Copyright Alignment','freelancer-services'),
        'section' => 'freelancer_services_footer',
        'settings' => 'freelancer_services_copyright_alingment',
        'choices' => array(
            'left' => esc_url(get_template_directory_uri()).'/assets/images/copyright1.png',
            'center' => esc_url(get_template_directory_uri()).'/assets/images/copyright2.png',
            'right' => esc_url(get_template_directory_uri()).'/assets/images/copyright3.png'
    ))));

    $wp_customize->add_setting( 'freelancer_services_hide_show_scroll',array(
    	'default' => 1,
      	'transport' => 'refresh',
      	'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));  
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_hide_show_scroll',array(
      	'label' => esc_html__( 'Show / Hide Scroll to Top','freelancer-services' ),
      	'section' => 'freelancer_services_footer'
    )));

     //Selective Refresh
	$wp_customize->selective_refresh->add_partial('freelancer_services_scroll_to_top_icon', array( 
		'selector' => '.scrollup i', 
		'render_callback' => 'freelancer_services_Customize_partial_freelancer_services_scroll_to_top_icon', 
	));

    $wp_customize->add_setting('freelancer_services_scroll_to_top_icon',array(
		'default'	=> 'fas fa-long-arrow-alt-up',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_scroll_to_top_icon',array(
		'label'	=> __('Add Scroll to Top Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_footer',
		'setting'	=> 'freelancer_services_scroll_to_top_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting('freelancer_services_scroll_to_top_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_scroll_to_top_font_size',array(
		'label'	=> __('Icon Font Size','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_scroll_to_top_padding',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_scroll_to_top_padding',array(
		'label'	=> __('Icon Top Bottom Padding','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_scroll_to_top_width',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_scroll_to_top_width',array(
		'label'	=> __('Icon Width','freelancer-services'),
		'description'	=> __('Enter a value in pixels Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_scroll_to_top_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_scroll_to_top_height',array(
		'label'	=> __('Icon Height','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'freelancer_services_scroll_to_top_border_radius', array(
		'default'              => '',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_scroll_to_top_border_radius', array(
		'label'       => esc_html__( 'Icon Border Radius','freelancer-services' ),
		'section'     => 'freelancer_services_footer',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

    $wp_customize->add_setting('freelancer_services_scroll_top_alignment',array(
        'default' => 'Right',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control(new Freelancer_Services_Image_Radio_Control($wp_customize, 'freelancer_services_scroll_top_alignment', array(
        'type' => 'select',
        'label' => esc_html__('Scroll To Top','freelancer-services'),
        'section' => 'freelancer_services_footer',
        'settings' => 'freelancer_services_scroll_top_alignment',
        'choices' => array(
            'Left' => esc_url(get_template_directory_uri()).'/assets/images/layout1.png',
            'Center' => esc_url(get_template_directory_uri()).'/assets/images/layout2.png',
            'Right' => esc_url(get_template_directory_uri()).'/assets/images/layout3.png'
    ))));

	//Blog Post
	$wp_customize->add_panel( 'freelancer_services_blog_post_parent_panel', array(
		'title' => esc_html__( 'Blog Post Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_panel_id',
		'priority' => 20,
	));

	// Add example section and controls to the middle (second) panel
	$wp_customize->add_section( 'freelancer_services_post_settings', array(
		'title' => esc_html__( 'Post Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_blog_post_parent_panel',
	));

	//Blog layout
    $wp_customize->add_setting('freelancer_services_blog_layout_option',array(
        'default' => 'Default',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
    ));
    $wp_customize->add_control(new Freelancer_Services_Image_Radio_Control($wp_customize, 'freelancer_services_blog_layout_option', array(
        'type' => 'select',
        'label' => __('Blog Post Layouts','freelancer-services'),
        'section' => 'freelancer_services_post_settings',
        'choices' => array(
            'Default' => esc_url(get_template_directory_uri()).'/assets/images/blog-layout1.png',
            'Center' => esc_url(get_template_directory_uri()).'/assets/images/blog-layout2.png',
            'Left' => esc_url(get_template_directory_uri()).'/assets/images/blog-layout3.png',
    ))));

   	$wp_customize->add_setting('freelancer_services_theme_options',array(
        'default' => 'Right Sidebar',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_theme_options',array(
        'type' => 'select',
        'label' => esc_html__('Post Sidebar Layout','freelancer-services'),
        'description' => esc_html__('Here you can change the sidebar layout for posts. ','freelancer-services'),
        'section' => 'freelancer_services_post_settings',
        'choices' => array(
            'Left Sidebar' => esc_html__('Left Sidebar','freelancer-services'),
            'Right Sidebar' => esc_html__('Right Sidebar','freelancer-services'),
            'One Column' => esc_html__('One Column','freelancer-services'),
			'Three Columns' => __('Three Columns','freelancer-services'),
			'Four Columns' => __('Four Columns','freelancer-services'),
            'Grid Layout' => esc_html__('Grid Layout','freelancer-services')
        ),
	) );

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('freelancer_services_toggle_postdate', array( 
		'selector' => '.post-main-box h2 a', 
		'render_callback' => 'freelancer_services_Customize_partial_freelancer_services_toggle_postdate', 
	));

  	$wp_customize->add_setting('freelancer_services_toggle_postdate_icon',array(
		'default'	=> 'fas fa-calendar-alt',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_toggle_postdate_icon',array(
		'label'	=> __('Add Post Date Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_post_settings',
		'setting'	=> 'freelancer_services_toggle_postdate_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'freelancer_services_toggle_postdate',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_toggle_postdate',array(
        'label' => esc_html__( 'Show / Hide Post Date','freelancer-services' ),
        'section' => 'freelancer_services_post_settings'
    )));

	$wp_customize->add_setting('freelancer_services_toggle_author_icon',array(
		'default'	=> 'fas fa-user',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_toggle_author_icon',array(
		'label'	=> __('Add Author Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_post_settings',
		'setting'	=> 'freelancer_services_toggle_author_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_toggle_author',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_toggle_author',array(
		'label' => esc_html__( 'Show / Hide Author','freelancer-services' ),
		'section' => 'freelancer_services_post_settings'
    )));

    $wp_customize->add_setting('freelancer_services_toggle_comments_icon',array(
		'default'	=> 'fa fa-comments',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_toggle_comments_icon',array(
		'label'	=> __('Add Comments Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_post_settings',
		'setting'	=> 'freelancer_services_toggle_comments_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_toggle_comments',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_toggle_comments',array(
		'label' => esc_html__( 'Show / Hide Comments','freelancer-services' ),
		'section' => 'freelancer_services_post_settings'
    )));

  	$wp_customize->add_setting('freelancer_services_toggle_time_icon',array(
		'default'	=> 'fas fa-clock',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_toggle_time_icon',array(
		'label'	=> __('Add Time Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_post_settings',
		'setting'	=> 'freelancer_services_toggle_time_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_toggle_time',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_toggle_time',array(
		'label' => esc_html__( 'Show / Hide Time','freelancer-services' ),
		'section' => 'freelancer_services_post_settings'
    )));

    $wp_customize->add_setting( 'freelancer_services_featured_image_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_featured_image_hide_show', array(
		'label' => esc_html__( 'Show / Hide Featured Image','freelancer-services' ),
		'section' => 'freelancer_services_post_settings'
    )));

  	$wp_customize->add_setting( 'freelancer_services_featured_image_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_featured_image_border_radius', array(
		'label'       => esc_html__( 'Featured Image Border Radius','freelancer-services' ),
		'section'     => 'freelancer_services_post_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'freelancer_services_featured_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_featured_image_box_shadow', array(
		'label'       => esc_html__( 'Featured Image Box Shadow','freelancer-services' ),
		'section'     => 'freelancer_services_post_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	//Featured Image
	$wp_customize->add_setting('freelancer_services_blog_post_featured_image_dimension',array(
       'default' => 'default',
       'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
	));
  	$wp_customize->add_control('freelancer_services_blog_post_featured_image_dimension',array(
		'type' => 'select',
		'label'	=> __('Blog Post Featured Image Dimension','freelancer-services'),
		'section'	=> 'freelancer_services_post_settings',
		'choices' => array(
		'default' => __('Default','freelancer-services'),
		'custom' => __('Custom Image Size','freelancer-services'),
      ),
  	));

	$wp_customize->add_setting('freelancer_services_blog_post_featured_image_custom_width',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
		));
	$wp_customize->add_control('freelancer_services_blog_post_featured_image_custom_width',array(
		'label'	=> __('Featured Image Custom Width','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
    	'placeholder' => __( '10px', 'freelancer-services' ),),
		'section'=> 'freelancer_services_post_settings',
		'type'=> 'text',
		'active_callback' => 'freelancer_services_blog_post_featured_image_dimension'
		));

	$wp_customize->add_setting('freelancer_services_blog_post_featured_image_custom_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_blog_post_featured_image_custom_height',array(
		'label'	=> __('Featured Image Custom Height','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
    	'placeholder' => __( '10px', 'freelancer-services' ),),
		'section'=> 'freelancer_services_post_settings',
		'type'=> 'text',
		'active_callback' => 'freelancer_services_blog_post_featured_image_dimension'
	));

    $wp_customize->add_setting( 'freelancer_services_toggle_tags',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_toggle_tags', array(
		'label' => esc_html__( 'Show / Hide Tags','freelancer-services' ),
		'section' => 'freelancer_services_post_settings'
    )));

    $wp_customize->add_setting( 'freelancer_services_excerpt_number', array(
		'default'              => 30,
		'type'                 => 'theme_mod',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range',
		'sanitize_js_callback' => 'absint',
	) );
	$wp_customize->add_control( 'freelancer_services_excerpt_number', array(
		'label'       => esc_html__( 'Excerpt length','freelancer-services' ),
		'section'     => 'freelancer_services_post_settings',
		'type'        => 'range',
		'settings'    => 'freelancer_services_excerpt_number',
		'input_attrs' => array(
			'step'             => 5,
			'min'              => 0,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting('freelancer_services_meta_field_separator',array(
		'default'=> '|',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_meta_field_separator',array(
		'label'	=> __('Add Meta Separator','freelancer-services'),
		'description' => __('Add the seperator for meta box. Example: "|", "/", etc.','freelancer-services'),
		'section'=> 'freelancer_services_post_settings',
		'type'=> 'text'
	));

    $wp_customize->add_setting('freelancer_services_excerpt_settings',array(
        'default' => 'Excerpt',
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_excerpt_settings',array(
        'type' => 'select',
        'label' => esc_html__('Post Content','freelancer-services'),
        'section' => 'freelancer_services_post_settings',
        'choices' => array(
        	'Content' => esc_html__('Content','freelancer-services'),
            'Excerpt' => esc_html__('Excerpt','freelancer-services'),
            'No Content' => esc_html__('No Content','freelancer-services')
        ),
	) );

    $wp_customize->add_setting('freelancer_services_blog_page_posts_settings',array(
        'default' => 'Into Blocks',
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_blog_page_posts_settings',array(
        'type' => 'select',
        'label' => __('Display Blog posts','freelancer-services'),
        'section' => 'freelancer_services_post_settings',
        'choices' => array(
        	'Into Blocks' => __('Into Blocks','freelancer-services'),
            'Without Blocks' => __('Without Blocks','freelancer-services')
        ),
	) );

	$wp_customize->add_setting( 'freelancer_services_blog_pagination_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_blog_pagination_hide_show',array(
		'label' => esc_html__( 'Show / Hide Blog Pagination','freelancer-services' ),
		'section' => 'freelancer_services_post_settings'
    )));

	$wp_customize->add_setting( 'freelancer_services_blog_pagination_type', array(
        'default'			=> 'blog-page-numbers',
        'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
    ));
    $wp_customize->add_control( 'freelancer_services_blog_pagination_type', array(
        'section' => 'freelancer_services_post_settings',
        'type' => 'select',
        'label' => __( 'Blog Pagination', 'freelancer-services' ),
        'choices'		=> array(
            'blog-page-numbers'  => __( 'Numeric', 'freelancer-services' ),
            'next-prev' => __( 'Older Posts/Newer Posts', 'freelancer-services' ),
    )));

    // Button Settings
	$wp_customize->add_section( 'freelancer_services_button_settings', array(
		'title' => esc_html__( 'Button Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_blog_post_parent_panel',
	));

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('freelancer_services_button_text', array( 
		'selector' => '.post-main-box .more-btn a', 
		'render_callback' => 'freelancer_services_Customize_partial_freelancer_services_button_text', 
	));

    $wp_customize->add_setting('freelancer_services_button_text',array(
		'default'=> esc_html__('Read More','freelancer-services'),
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_text',array(
		'label'	=> esc_html__('Add Button Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Read More', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_button_settings',
		'type'=> 'text'
	));

	// font size button
	$wp_customize->add_setting('freelancer_services_button_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_font_size',array(
		'label'	=> __('Button Font Size','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
      	'placeholder' => __( '10px', 'freelancer-services' ),
    ),
    	'type'        => 'text',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
		'section'=> 'freelancer_services_button_settings',
	));

	$wp_customize->add_setting( 'freelancer_services_button_border_radius', array(
		'default'              => 5,
		'type'                 => 'theme_mod',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range',
		'sanitize_js_callback' => 'absint',
	) );
	$wp_customize->add_control( 'freelancer_services_button_border_radius', array(
		'label'       => esc_html__( 'Button Border Radius','freelancer-services' ),
		'section'     => 'freelancer_services_button_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting('freelancer_services_button_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_padding_top_bottom',array(
		'label'	=> __('Padding Top Bottom','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_button_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_button_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_padding_left_right',array(
		'label'	=> __('Padding Left Right','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_button_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_button_letter_spacing',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_button_letter_spacing',array(
		'label'	=> __('Button Letter Spacing','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
      	'placeholder' => __( '10px', 'freelancer-services' ),
    ),
    	'type'        => 'text',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
		'section'=> 'freelancer_services_button_settings',
	));

	// text trasform
	$wp_customize->add_setting('freelancer_services_button_text_transform',array(
		'default'=> 'Uppercase',
		'sanitize_callback'	=> 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_button_text_transform',array(
		'type' => 'radio',
		'label'	=> __('Button Text Transform','freelancer-services'),
		'choices' => array(
            'Uppercase' => __('Uppercase','freelancer-services'),
            'Capitalize' => __('Capitalize','freelancer-services'),
            'Lowercase' => __('Lowercase','freelancer-services'),
        ),
		'section'=> 'freelancer_services_button_settings',
	));

	// Related Post Settings
	$wp_customize->add_section( 'freelancer_services_related_posts_settings', array(
		'title' => esc_html__( 'Related Posts Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_blog_post_parent_panel',
	));

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('freelancer_services_related_post_title', array( 
		'selector' => '.related-post h3', 
		'render_callback' => 'freelancer_services_Customize_partial_freelancer_services_related_post_title', 
	));

    $wp_customize->add_setting( 'freelancer_services_related_post',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_post',array(
		'label' => esc_html__( 'Show / Hide Related Post','freelancer-services' ),
		'section' => 'freelancer_services_related_posts_settings'
    )));

    $wp_customize->add_setting('freelancer_services_related_post_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_related_post_title',array(
		'label'	=> esc_html__('Add Related Post Title','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Related Post', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_related_posts_settings',
		'type'=> 'text'
	));

   	$wp_customize->add_setting('freelancer_services_related_posts_count',array(
		'default'=> 3,
		'sanitize_callback'	=> 'freelancer_services_sanitize_number_absint'
	));
	$wp_customize->add_control('freelancer_services_related_posts_count',array(
		'label'	=> esc_html__('Add Related Post Count','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => esc_html__( '3', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_related_posts_settings',
		'type'=> 'number'
	));

	$wp_customize->add_setting( 'freelancer_services_related_posts_excerpt_number', array(
		'default'              => 20,
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_related_posts_excerpt_number', array(
		'label'       => esc_html__( 'Related Posts Excerpt length','freelancer-services' ),
		'section'     => 'freelancer_services_related_posts_settings',
		'type'        => 'range',
		'settings'    => 'freelancer_services_related_posts_excerpt_number',
		'input_attrs' => array(
			'step'             => 5,
			'min'              => 0,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'freelancer_services_related_toggle_postdate',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
  	));
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_toggle_postdate',array(
	    'label' => esc_html__( 'Show / Hide Post Date','freelancer-services' ),
	    'section' => 'freelancer_services_related_posts_settings'
  	)));

  	$wp_customize->add_setting('freelancer_services_related_postdate_icon',array(
	    'default' => 'fas fa-calendar-alt',
	    'sanitize_callback' => 'sanitize_text_field'
  	));
  	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
  	$wp_customize,'freelancer_services_related_postdate_icon',array(
	    'label' => __('Add Post Date Icon','freelancer-services'),
	    'transport' => 'refresh',
	    'section' => 'freelancer_services_related_posts_settings',
	    'setting' => 'freelancer_services_related_postdate_icon',
	    'type'    => 'icon'
  	)));

	$wp_customize->add_setting( 'freelancer_services_related_toggle_author',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
  	));
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_toggle_author',array(
		'label' => esc_html__( 'Show / Hide Author','freelancer-services' ),
		'section' => 'freelancer_services_related_posts_settings'
  	)));

  	$wp_customize->add_setting('freelancer_services_related_author_icon',array(
	    'default' => 'fas fa-user',
	    'sanitize_callback' => 'sanitize_text_field'
  	));
  	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
  	$wp_customize,'freelancer_services_related_author_icon',array(
	    'label' => __('Add Author Icon','freelancer-services'),
	    'transport' => 'refresh',
	    'section' => 'freelancer_services_related_posts_settings',
	    'setting' => 'freelancer_services_related_author_icon',
	    'type'    => 'icon'
  	)));

	$wp_customize->add_setting( 'freelancer_services_related_toggle_comments',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
  	) );
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_toggle_comments',array(
		'label' => esc_html__( 'Show / Hide Comments','freelancer-services' ),
		'section' => 'freelancer_services_related_posts_settings'
  	)));

  	$wp_customize->add_setting('freelancer_services_related_comments_icon',array(
	    'default' => 'fa fa-comments',
	    'sanitize_callback' => 'sanitize_text_field'
  	));
  	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
  	$wp_customize,'freelancer_services_related_comments_icon',array(
	    'label' => __('Add Comments Icon','freelancer-services'),
	    'transport' => 'refresh',
	    'section' => 'freelancer_services_related_posts_settings',
	    'setting' => 'freelancer_services_related_comments_icon',
	    'type'    => 'icon'
  	)));

	$wp_customize->add_setting( 'freelancer_services_related_toggle_time',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
  	) );
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_toggle_time',array(
		'label' => esc_html__( 'Show / Hide Time','freelancer-services' ),
		'section' => 'freelancer_services_related_posts_settings'
  	)));

  	$wp_customize->add_setting('freelancer_services_related_time_icon',array(
	    'default' => 'fas fa-clock',
	    'sanitize_callback' => 'sanitize_text_field'
  	));
  	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
  	$wp_customize,'freelancer_services_related_time_icon',array(
	    'label' => __('Add Time Icon','freelancer-services'),
	    'transport' => 'refresh',
	    'section' => 'freelancer_services_related_posts_settings',
	    'setting' => 'freelancer_services_related_time_icon',
	    'type'    => 'icon'
  	)));

  	$wp_customize->add_setting('freelancer_services_related_post_meta_field_separator',array(
		'default'=> '|',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_related_post_meta_field_separator',array(
		'label'	=> __('Add Meta Separator','freelancer-services'),
		'description' => __('Add the seperator for meta box. Example: "|", "/", etc.','freelancer-services'),
		'section'=> 'freelancer_services_related_posts_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'freelancer_services_related_image_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_image_hide_show', array(
		'label' => esc_html__( 'Show / Hide Featured Image','freelancer-services' ),
		'section' => 'freelancer_services_related_posts_settings'
  	)));

  	$wp_customize->add_setting( 'freelancer_services_related_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_related_image_box_shadow', array(
		'label'       => esc_html__( 'Related post Image Box Shadow','freelancer-services' ),
		'section'     => 'freelancer_services_related_posts_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

  	$wp_customize->add_setting('freelancer_services_related_button_text',array(
		'default'=> esc_html__('Read More','freelancer-services'),
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_related_button_text',array(
		'label'	=> esc_html__('Add Button Text','freelancer-services'),
		'input_attrs' => array(
      'placeholder' => esc_html__( 'Read More', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_related_posts_settings',
		'type'=> 'text'
	));

	// Single Posts Settings
	$wp_customize->add_section( 'freelancer_services_single_blog_settings', array(
		'title' => __( 'Single Post Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_blog_post_parent_panel',
	));

  	$wp_customize->add_setting('freelancer_services_single_postdate_icon',array(
		'default'	=> 'fas fa-calendar-alt',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_single_postdate_icon',array(
		'label'	=> __('Add Post Date Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_single_blog_settings',
		'setting'	=> 'freelancer_services_single_postdate_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_single_postdate',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
	) );
	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_postdate',array(
	    'label' => esc_html__( 'Show / Hide Date','freelancer-services' ),
	   'section' => 'freelancer_services_single_blog_settings'
	)));

	$wp_customize->add_setting('freelancer_services_single_author_icon',array(
		'default'	=> 'fas fa-user',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_single_author_icon',array(
		'label'	=> __('Add Author Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_single_blog_settings',
		'setting'	=> 'freelancer_services_single_author_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_single_author',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
	) );
	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_author',array(
	    'label' => esc_html__( 'Show / Hide Author','freelancer-services' ),
	    'section' => 'freelancer_services_single_blog_settings'
	)));

   	$wp_customize->add_setting('freelancer_services_single_comments_icon',array(
		'default'	=> 'fa fa-comments',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_single_comments_icon',array(
		'label'	=> __('Add Comments Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_single_blog_settings',
		'setting'	=> 'freelancer_services_single_comments_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'freelancer_services_single_comments',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
	) );
	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_comments',array(
	    'label' => esc_html__( 'Show / Hide Comments','freelancer-services' ),
	    'section' => 'freelancer_services_single_blog_settings'
	)));

  	$wp_customize->add_setting('freelancer_services_single_time_icon',array(
		'default'	=> 'fas fa-clock',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_single_time_icon',array(
		'label'	=> __('Add Time Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_single_blog_settings',
		'setting'	=> 'freelancer_services_single_time_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'freelancer_services_single_time',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
	) );
	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_time',array(
	    'label' => esc_html__( 'Show / Hide Time','freelancer-services' ),
	    'section' => 'freelancer_services_single_blog_settings'
	)));

	$wp_customize->add_setting( 'freelancer_services_single_post_breadcrumb',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_post_breadcrumb',array(
		'label' => esc_html__( 'Show / Hide Breadcrumb','freelancer-services' ),
		'section' => 'freelancer_services_single_blog_settings'
    )));

     // Single Posts Category
  	$wp_customize->add_setting( 'freelancer_services_single_post_category',array(
		'default' => true,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_post_category',array(
		'label' => esc_html__( 'Show / Hide Category','freelancer-services' ),
		'section' => 'freelancer_services_single_blog_settings'
    )));

	$wp_customize->add_setting( 'freelancer_services_toggle_tags',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_toggle_tags', array(
		'label' => esc_html__( 'Show / Hide Tags','freelancer-services' ),
		'section' => 'freelancer_services_single_blog_settings'
    )));
 
	$wp_customize->add_setting( 'freelancer_services_single_blog_post_navigation_show_hide',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_blog_post_navigation_show_hide', array(
		'label' => esc_html__( 'Show / Hide Post Navigation','freelancer-services' ),
		'section' => 'freelancer_services_single_blog_settings'
    )));

	//navigation text
	$wp_customize->add_setting('freelancer_services_single_blog_prev_navigation_text',array(
		'default'=> 'PREVIOUS',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_single_blog_prev_navigation_text',array(
		'label'	=> __('Post Navigation Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'PREVIOUS', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_single_blog_settings',
		'type'=> 'text'
	)); 

	$wp_customize->add_setting('freelancer_services_single_blog_next_navigation_text',array(
		'default'=> 'NEXT',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_single_blog_next_navigation_text',array(
		'label'	=> __('Post Navigation Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'NEXT', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'freelancer_services_singlepost_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_singlepost_image_box_shadow', array(
		'label'       => esc_html__( 'Single post Image Box Shadow','freelancer-services' ),
		'section'     => 'freelancer_services_single_blog_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting('freelancer_services_single_post_meta_field_separator',array(
		'default'=> '|',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_single_post_meta_field_separator',array(
		'label'	=> __('Add Meta Separator','freelancer-services'),
		'description' => __('Add the seperator for meta box. Example: "|", "/", etc.','freelancer-services'),
		'section'=> 'freelancer_services_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_single_blog_comment_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('freelancer_services_single_blog_comment_title',array(
		'label'	=> __('Add Comment Title','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'Leave a Reply', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_single_blog_comment_button_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('freelancer_services_single_blog_comment_button_text',array(
		'label'	=> __('Add Comment Button Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'Post Comment', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_single_blog_comment_width',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_single_blog_comment_width',array(
		'label'	=> __('Comment Form Width','freelancer-services'),
		'description'	=> __('Enter a value in %. Example:50%','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '100%', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_single_blog_settings',
		'type'=> 'text'
	));

    // Grid layout setting
	$wp_customize->add_section( 'freelancer_services_grid_layout_settings', array(
		'title' => __( 'Grid Layout Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_blog_post_parent_panel',
	));

  	$wp_customize->add_setting('freelancer_services_grid_postdate_icon',array(
		'default'	=> 'fas fa-calendar-alt',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_grid_postdate_icon',array(
		'label'	=> __('Add Post Date Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_grid_layout_settings',
		'setting'	=> 'freelancer_services_grid_postdate_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'freelancer_services_grid_postdate',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_grid_postdate',array(
        'label' => esc_html__( 'Show / Hide Post Date','freelancer-services' ),
        'section' => 'freelancer_services_grid_layout_settings'
    )));

	$wp_customize->add_setting('freelancer_services_grid_author_icon',array(
		'default'	=> 'fas fa-user',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_grid_author_icon',array(
		'label'	=> __('Add Author Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_grid_layout_settings',
		'setting'	=> 'freelancer_services_grid_author_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_grid_author',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_grid_author',array(
		'label' => esc_html__( 'Show / Hide Author','freelancer-services' ),
		'section' => 'freelancer_services_grid_layout_settings'
    )));

   	$wp_customize->add_setting('freelancer_services_grid_comments_icon',array(
		'default'	=> 'fa fa-comments',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_grid_comments_icon',array(
		'label'	=> __('Add Comments Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_grid_layout_settings',
		'setting'	=> 'freelancer_services_grid_comments_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'freelancer_services_grid_comments',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_grid_comments',array(
		'label' => esc_html__( 'Show / Hide Comments','freelancer-services' ),
		'section' => 'freelancer_services_grid_layout_settings'
    )));

    $wp_customize->add_setting( 'freelancer_services_grid_image_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
	));
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_grid_image_hide_show', array(
		'label' => esc_html__( 'Show / Hide Featured Image','freelancer-services' ),
		'section' => 'freelancer_services_grid_layout_settings'
  	)));

 	$wp_customize->add_setting('freelancer_services_grid_post_meta_field_separator',array(
		'default'=> '|',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_grid_post_meta_field_separator',array(
		'label'	=> __('Add Meta Separator','freelancer-services'),
		'description' => __('Add the seperator for meta box. Example: "|", "/", etc.','freelancer-services'),
		'section'=> 'freelancer_services_grid_layout_settings',
		'type'=> 'text'
	));

    $wp_customize->add_setting('freelancer_services_display_grid_posts_settings',array(
        'default' => 'Into Blocks',
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_display_grid_posts_settings',array(
        'type' => 'select',
        'label' => __('Display Grid Posts','freelancer-services'),
        'section' => 'freelancer_services_grid_layout_settings',
        'choices' => array(
        	'Into Blocks' => __('Into Blocks','freelancer-services'),
            'Without Blocks' => __('Without Blocks','freelancer-services')
        ),
	) );

	$wp_customize->add_setting('freelancer_services_grid_button_text',array(
		'default'=> esc_html__('Read More','freelancer-services'),
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_grid_button_text',array(
		'label'	=> esc_html__('Add Button Text','freelancer-services'),
		'input_attrs' => array(
        'placeholder' => esc_html__( 'Read More', 'freelancer-services' ),
      ),
		'section'=> 'freelancer_services_grid_layout_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_grid_excerpt_suffix',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_grid_excerpt_suffix',array(
		'label'	=> __('Add Excerpt Suffix','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '[...]', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_grid_layout_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_grid_excerpt_settings',array(
        'default' => 'Excerpt',
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_grid_excerpt_settings',array(
        'type' => 'select',
        'label' => esc_html__('Grid Post Content','freelancer-services'),
        'section' => 'freelancer_services_grid_layout_settings',
        'choices' => array(
        	'Content' => esc_html__('Content','freelancer-services'),
            'Excerpt' => esc_html__('Excerpt','freelancer-services'),
            'No Content' => esc_html__('No Content','freelancer-services')
        ),
	) );

	$wp_customize->add_setting( 'freelancer_services_grid_featured_image_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_grid_featured_image_border_radius', array(
		'label'       => esc_html__( 'Grid Featured Image Border Radius','freelancer-services' ),
		'section'     => 'freelancer_services_grid_layout_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'freelancer_services_grid_featured_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_grid_featured_image_box_shadow', array(
		'label'       => esc_html__( 'Grid Featured Image Box Shadow','freelancer-services' ),
		'section'     => 'freelancer_services_grid_layout_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

    //Others Settings
	$wp_customize->add_panel( 'freelancer_services_others_panel', array(
		'title' => esc_html__( 'Others Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_panel_id',
		'priority' => 20,
	));

	// Layout
	$wp_customize->add_section( 'freelancer_services_left_right', array(
    	'title' => esc_html__( 'General Settings', 'freelancer-services' ),
		'panel' => 'freelancer_services_others_panel'
	) );

	$wp_customize->add_setting('freelancer_services_width_option',array(
        'default' => 'Full Width',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control(new Freelancer_Services_Image_Radio_Control($wp_customize, 'freelancer_services_width_option', array(
        'type' => 'select',
        'label' => esc_html__('Width Layouts','freelancer-services'),
        'description' => esc_html__('Here you can change the width layout of Website.','freelancer-services'),
        'section' => 'freelancer_services_left_right',
        'choices' => array(
            'Full Width' => esc_url(get_template_directory_uri()).'/assets/images/full-width.png',
            'Wide Width' => esc_url(get_template_directory_uri()).'/assets/images/wide-width.png',
            'Boxed' => esc_url(get_template_directory_uri()).'/assets/images/boxed-width.png',
    ))));

	$wp_customize->add_setting('freelancer_services_page_layout',array(
        'default' => 'One_Column',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_page_layout',array(
        'type' => 'select',
        'label' => esc_html__('Page Sidebar Layout','freelancer-services'),
        'description' => esc_html__('Here you can change the sidebar layout for pages. ','freelancer-services'),
        'section' => 'freelancer_services_left_right',
        'choices' => array(
            'Left_Sidebar' => esc_html__('Left Sidebar','freelancer-services'),
            'Right_Sidebar' => esc_html__('Right Sidebar','freelancer-services'),
            'One_Column' => esc_html__('One Column','freelancer-services')
        ),
	) );

    $wp_customize->add_setting( 'freelancer_services_single_page_breadcrumb',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_single_page_breadcrumb',array(
		'label' => esc_html__( 'Show / Hide Page Breadcrumb','freelancer-services' ),
		'section' => 'freelancer_services_left_right'
    )));

    //Wow Animation
	$wp_customize->add_setting( 'freelancer_services_animation',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_animation',array(
        'label' => esc_html__( 'Show / Hide Animations','freelancer-services' ),
        'description' => __('Here you can disable overall site animation effect','freelancer-services'),
        'section' => 'freelancer_services_left_right'
    )));

    // Pre-Loader
	$wp_customize->add_setting( 'freelancer_services_loader_enable',array(
        'default' => 0,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_loader_enable',array(
        'label' => esc_html__( 'Show / Hide Pre-Loader','freelancer-services' ),
        'section' => 'freelancer_services_left_right'
    )));

	$wp_customize->add_setting('freelancer_services_preloader_bg_color', array(
		'default'           => '#6102d3',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_preloader_bg_color', array(
		'label'    => __('Pre-Loader Background Color', 'freelancer-services'),
		'section'  => 'freelancer_services_left_right',
	)));

	$wp_customize->add_setting('freelancer_services_preloader_border_color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_preloader_border_color', array(
		'label'    => __('Pre-Loader Border Color', 'freelancer-services'),
		'section'  => 'freelancer_services_left_right',
	)));

	$wp_customize->add_setting('freelancer_services_preloader_bg_img',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw',
	));
	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize,'freelancer_services_preloader_bg_img',array(
        'label' => __('Preloader Background Image','freelancer-services'),
        'section' => 'freelancer_services_left_right'
	)));

	$wp_customize->add_setting('freelancer_services_bradcrumbs_alignment',array(
        'default' => 'Left',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_bradcrumbs_alignment',array(
        'type' => 'select',
        'label' => __('Bradcrumbs Alignment','freelancer-services'),
        'section' => 'freelancer_services_left_right',
        'choices' => array(
            'Left' => __('Left','freelancer-services'),
            'Right' => __('Right','freelancer-services'),
            'Center' => __('Center','freelancer-services'),
        ),
	) );

    //404 Page Setting
	$wp_customize->add_section('freelancer_services_404_page',array(
		'title'	=> __('404 Page Settings','freelancer-services'),
		'panel' => 'freelancer_services_others_panel',
	));

	$wp_customize->add_setting('freelancer_services_404_page_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('freelancer_services_404_page_title',array(
		'label'	=> __('Add Title','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '404 Not Found', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_404_page',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_404_page_content',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('freelancer_services_404_page_content',array(
		'label'	=> __('Add Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'Looks like you have taken a wrong turn, Dont worry, it happens to the best of us.', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_404_page',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_404_page_button_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_404_page_button_text',array(
		'label'	=> __('Add Button Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'GO BACK', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_404_page',
		'type'=> 'text'
	));

	//No Result Page Setting
	$wp_customize->add_section('freelancer_services_no_results_page',array(
		'title'	=> __('No Results Page Settings','freelancer-services'),
		'panel' => 'freelancer_services_others_panel',
	));

	$wp_customize->add_setting('freelancer_services_no_results_page_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('freelancer_services_no_results_page_title',array(
		'label'	=> __('Add Title','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'Nothing Found', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_no_results_page',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_no_results_page_content',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('freelancer_services_no_results_page_content',array(
		'label'	=> __('Add Text','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_no_results_page',
		'type'=> 'text'
	));

	//Social Icon Setting
	$wp_customize->add_section('freelancer_services_social_icon_settings',array(
		'title'	=> __('Social Icons Settings','freelancer-services'),
		'panel' => 'freelancer_services_others_panel',
	));

	$wp_customize->add_setting('freelancer_services_social_icon_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_social_icon_font_size',array(
		'label'	=> __('Icon Font Size','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_social_icon_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_social_icon_padding',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_social_icon_padding',array(
		'label'	=> __('Icon Padding','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_social_icon_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_social_icon_width',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_social_icon_width',array(
		'label'	=> __('Icon Width','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
    'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_social_icon_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_social_icon_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_social_icon_height',array(
		'label'	=> __('Icon Height','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_social_icon_settings',
		'type'=> 'text'
	));


	//Responsive Media Settings
	$wp_customize->add_section('freelancer_services_responsive_media',array(
		'title'	=> esc_html__('Responsive Media','freelancer-services'),
		'panel' => 'freelancer_services_others_panel',
	));

	$wp_customize->add_setting( 'freelancer_services_stickyheader_hide_show',array(
	    'default' => 0,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'freelancer_services_switch_sanitization'
  	));  
  	$wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_stickyheader_hide_show',array(
    'label' => esc_html__( 'Show / Hide Sticky Header','freelancer-services' ),
    'section' => 'freelancer_services_responsive_media'
  	)));

    $wp_customize->add_setting( 'freelancer_services_resp_slider_hide_show',array(
      	'default' => 1,
     	'transport' => 'refresh',
      	'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));  
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_resp_slider_hide_show',array(
      	'label' => esc_html__( 'Show / Hide Slider','freelancer-services' ),
      	'section' => 'freelancer_services_responsive_media'
    )));

    $wp_customize->add_setting( 'freelancer_services_sidebar_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));  
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_sidebar_hide_show',array(
      	'label' => esc_html__( 'Show / Hide Sidebar','freelancer-services' ),
      	'section' => 'freelancer_services_responsive_media'
    )));

    $wp_customize->add_setting( 'freelancer_services_responsive_preloader_hide',array(
        'default' => false,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_responsive_preloader_hide',array(
        'label' => esc_html__( 'Show / Hide Preloader','freelancer-services' ),
        'section' => 'freelancer_services_responsive_media'
    )));

    $wp_customize->add_setting( 'freelancer_services_resp_scroll_top_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ));  
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_resp_scroll_top_hide_show',array(
      	'label' => esc_html__( 'Show / Hide Scroll To Top','freelancer-services' ),
      	'section' => 'freelancer_services_responsive_media'
    )));

    $wp_customize->add_setting('freelancer_services_res_open_menu_icon',array(
		'default'	=> 'fas fa-bars',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_res_open_menu_icon',array(
		'label'	=> __('Add Open Menu Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_responsive_media',
		'setting'	=> 'freelancer_services_res_open_menu_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting('freelancer_services_res_menu_close_icon',array(
		'default'	=> 'fas fa-times',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control(new Freelancer_Services_Fontawesome_Icon_Chooser(
        $wp_customize,'freelancer_services_res_menu_close_icon',array(
		'label'	=> __('Add Close Menu Icon','freelancer-services'),
		'transport' => 'refresh',
		'section'	=> 'freelancer_services_responsive_media',
		'setting'	=> 'freelancer_services_res_menu_close_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting('freelancer_services_resp_menu_toggle_btn_bg_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'freelancer_services_resp_menu_toggle_btn_bg_color', array(
		'label'    => __('Toggle Button Bg Color', 'freelancer-services'),
		'section'  => 'freelancer_services_responsive_media',
	)));

    //Woocommerce settings
	$wp_customize->add_section('freelancer_services_woocommerce_section', array(
		'title'    => __('WooCommerce Layout', 'freelancer-services'),
		'priority' => null,
		'panel'    => 'woocommerce',
	));

    //Shop Page Featured Image
	$wp_customize->add_setting( 'freelancer_services_shop_featured_image_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_shop_featured_image_border_radius', array(
		'label'       => esc_html__( 'Shop Page Featured Image Border Radius','freelancer-services' ),
		'section'     => 'freelancer_services_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'freelancer_services_shop_featured_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_shop_featured_image_box_shadow', array(
		'label'       => esc_html__( 'Shop Page Featured Image Box Shadow','freelancer-services' ),
		'section'     => 'freelancer_services_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	// Selective Refresh
	$wp_customize->selective_refresh->add_partial( 'freelancer_services_woocommerce_shop_page_sidebar', array( 'selector' => '.post-type-archive-product #sidebar', 
		'render_callback' => 'freelancer_services_customize_partial_freelancer_services_woocommerce_shop_page_sidebar', ) );

    // Woocommerce Shop Page Sidebar
	$wp_customize->add_setting( 'freelancer_services_woocommerce_shop_page_sidebar',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_woocommerce_shop_page_sidebar',array(
		'label' => esc_html__( 'Show / Hide Shop Page Sidebar','freelancer-services' ),
		'section' => 'freelancer_services_woocommerce_section'
    )));

    $wp_customize->add_setting('freelancer_services_shop_page_layout',array(
        'default' => 'Right Sidebar',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_shop_page_layout',array(
        'type' => 'select',
        'label' => __('Shop Page Sidebar Layout','freelancer-services'),
        'section' => 'freelancer_services_woocommerce_section',
        'choices' => array(
            'Left Sidebar' => __('Left Sidebar','freelancer-services'),
            'Right Sidebar' => __('Right Sidebar','freelancer-services'),
        ),
	) );

    // Selective Refresh
	$wp_customize->selective_refresh->add_partial( 'freelancer_services_woocommerce_single_product_page_sidebar', array( 'selector' => '.single-product #sidebar', 
		'render_callback' => 'freelancer_services_customize_partial_freelancer_services_woocommerce_single_product_page_sidebar', ) );

    //Woocommerce Single Product page Sidebar
	$wp_customize->add_setting( 'freelancer_services_woocommerce_single_product_page_sidebar',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );

    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_woocommerce_single_product_page_sidebar',array(
		'label' => esc_html__( 'Show / Hide Single Product Sidebar','freelancer-services' ),
		'section' => 'freelancer_services_woocommerce_section'
    )));

  	 $wp_customize->add_setting('freelancer_services_single_product_layout',array(
        'default' => 'Right Sidebar',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_single_product_layout',array(
        'type' => 'select',
        'label' => __('Single Product Sidebar Layout','freelancer-services'),
        'section' => 'freelancer_services_woocommerce_section',
        'choices' => array(
            'Left Sidebar' => __('Left Sidebar','freelancer-services'),
            'Right Sidebar' => __('Right Sidebar','freelancer-services'),
        ),
	) );

	$wp_customize->add_setting('freelancer_services_products_btn_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_products_btn_padding_top_bottom',array(
		'label'	=> __('Products Button Padding Top Bottom','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_products_btn_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_products_btn_padding_left_right',array(
		'label'	=> __('Products Button Padding Left Right','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'freelancer_services_products_button_border_radius', array(
		'default'              => '30',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'freelancer_services_sanitize_number_range'
	) );
	$wp_customize->add_control( 'freelancer_services_products_button_border_radius', array(
		'label'       => esc_html__( 'Products Button Border Radius','freelancer-services' ),
		'section'     => 'freelancer_services_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

    //Products Sale Badge
	$wp_customize->add_setting('freelancer_services_woocommerce_sale_position',array(
        'default' => 'left',
        'sanitize_callback' => 'freelancer_services_sanitize_choices'
	));
	$wp_customize->add_control('freelancer_services_woocommerce_sale_position',array(
        'type' => 'select',
        'label' => __('Sale Badge Position','freelancer-services'),
        'section' => 'freelancer_services_woocommerce_section',
        'choices' => array(
            'left' => __('Left','freelancer-services'),
            'right' => __('Right','freelancer-services'),
        ),
	) );

	$wp_customize->add_setting('freelancer_services_woocommerce_sale_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_woocommerce_sale_padding_top_bottom',array(
		'label'	=> __('Sale Padding Top Bottom','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('freelancer_services_woocommerce_sale_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('freelancer_services_woocommerce_sale_padding_left_right',array(
		'label'	=> __('Sale Padding Left Right','freelancer-services'),
		'description'	=> __('Enter a value in pixels. Example:20px','freelancer-services'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'freelancer-services' ),
        ),
		'section'=> 'freelancer_services_woocommerce_section',
		'type'=> 'text'
	));

  	// Related Product
    $wp_customize->add_setting( 'freelancer_services_related_product_show_hide',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'freelancer_services_switch_sanitization'
    ) );
    $wp_customize->add_control( new Freelancer_Services_Toggle_Switch_Custom_Control( $wp_customize, 'freelancer_services_related_product_show_hide',array(
        'label' => esc_html__( 'Show / Hide Related product','freelancer-services' ),
        'section' => 'freelancer_services_woocommerce_section'
    )));

}

add_action( 'customize_register', 'freelancer_services_customize_register' );

load_template( trailingslashit( get_template_directory() ) . '/inc/logo/logo-resizer.php' );

/**
 * Singleton class for handling the theme's customizer integration.
 *
 * @since  1.0.0
 * @access public
 */
final class Freelancer_Services_Customize {

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return object
	 */
	public static function get_instance() {

		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->setup_actions();
		}

		return $instance;
	}

	/**
	 * Constructor method.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function __construct() {}

	/**
	 * Sets up initial actions.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function setup_actions() {

		// Register panels, sections, settings, controls, and partials.
		add_action( 'customize_register', array( $this, 'sections' ) );

		// Register scripts and styles for the controls.
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_control_scripts' ), 0 );
	}

	/**
	 * Sets up the customizer sections.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @return void
	*/
	public function sections( $manager ) {

		// Load custom sections.
		load_template( trailingslashit( get_template_directory() ) . '/inc/section-pro.php' );

		// Register custom section types.
		$manager->register_section_type( 'Freelancer_Services_Customize_Section_Pro' );

		// Register sections.
		$manager->add_section( new Freelancer_Services_Customize_Section_Pro( $manager,'freelancer_services_go_pro', array(
			'priority'   => 1,
			'title'    => esc_html__( 'FREELANCER PRO', 'freelancer-services' ),
			'pro_text' => esc_html__( 'UPGRADE PRO', 'freelancer-services' ),
			'pro_url'  => esc_url('https://www.vwthemes.com/products/freelancer-wordpress-theme'),
		) )	);

		// Register sections.
		$manager->add_section(new Freelancer_Services_Customize_Section_Pro($manager,'freelancer_services_get_started_link',array(
			'priority'   => 1,
			'title'    => esc_html__( 'DOCUMENTATION', 'freelancer-services' ),
			'pro_text' => esc_html__( 'DOCS', 'freelancer-services' ),
			'pro_url'  => esc_url('https://preview.vwthemesdemo.com/docs/free-freelancer-services/'),
		)));
	}

	/**
	 * Loads theme customizer CSS.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue_control_scripts() {

		wp_enqueue_script( 'freelancer-services-customize-controls', trailingslashit( get_template_directory_uri() ) . '/assets/js/customize-controls.js', array( 'customize-controls' ) );

		wp_enqueue_style( 'freelancer-services-customize-controls', trailingslashit( get_template_directory_uri() ) . '/assets/css/customize-controls.css' );
	}
}

// Doing this customizer thang!
Freelancer_Services_Customize::get_instance();