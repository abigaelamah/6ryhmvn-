<?php

	$freelancer_services_custom_css= "";

	/*--------------------- Global First Color --------------------*/

	$freelancer_services_first_color = get_theme_mod('freelancer_services_first_color');

	if($freelancer_services_first_color != false){
		$freelancer_services_custom_css .='.more-btn a:hover,input[type="submit"]:hover,#comments input[type="submit"]:hover,#comments a.comment-reply-link:hover,.pagination .current,.pagination a:hover,#footer .tagcloud a:hover,#sidebar .tagcloud a:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.widget_product_search button:hover,nav.woocommerce-MyAccount-navigation ul li:hover, .getstarted-btn a, .main-navigation ul.sub-menu>li>a:before, .view-all-btn a:hover, .more-btn a:hover, #comments input[type="submit"]:hover,#comments a.comment-reply-link:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.pro-button a:hover, #services-sec .bx-image, #preloader, #footer-2, .scrollup i, .pagination span, .pagination a, .widget_product_search button, .post-categories li a, nav.navigation.posts-navigation .nav-previous a:hover, nav.navigation.posts-navigation .nav-next a:hover, .wp-block-button__link,a.wc-block-components-checkout-return-to-cart-button, .woocommerce nav.woocommerce-pagination ul li a{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_first_color).';';
		$freelancer_services_custom_css .='}';
	}

	if($freelancer_services_first_color != false){
		$freelancer_services_custom_css .='.wc-block-components-order-summary-item__quantity,.wp-block-woocommerce-cart .wc-block-cart__submit-button, .wc-block-components-checkout-place-order-button, .wc-block-components-totals-coupon__button{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_first_color).'!important;';
		$freelancer_services_custom_css .='}';
	}

	if($freelancer_services_first_color != false){
		$freelancer_services_custom_css .='.post-main-box h2 a,.post-main-box:hover .post-info span a, .single-post .post-info:hover a, .middle-bar h6{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_first_color).';';
		$freelancer_services_custom_css .='}';
	}

	if($freelancer_services_first_color != false){
		$freelancer_services_custom_css .='.more-btn a:hover,input[type="submit"]:hover,#comments input[type="submit"]:hover,#comments a.comment-reply-link:hover,.pagination .current,.pagination a:hover,#footer .tagcloud a:hover,#sidebar .tagcloud a:hover,.woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover,.woocommerce #respond input#submit.alt:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover,.widget_product_search button:hover,nav.woocommerce-MyAccount-navigation ul li:hover{';
			$freelancer_services_custom_css .='box-shadow: 0 0 10px '.esc_attr($freelancer_services_first_color).';';
		$freelancer_services_custom_css .='}';
	}

	if($freelancer_services_first_color != false){
		$freelancer_services_custom_css .='.getstarted-btn a{';
			$freelancer_services_custom_css .='box-shadow: -5px 5px 16px -3px '.esc_attr($freelancer_services_first_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_custom_css .='@media screen and (max-width:1000px) {';
		if($freelancer_services_first_color != false){
			$freelancer_services_custom_css .='.main-navigation a:hover{
			color:'.esc_attr($freelancer_services_first_color).'!important;
			}';
		}
	$freelancer_services_custom_css .='}';

	/*--------------------- Global Second Color --------------------*/

	$freelancer_services_second_color = get_theme_mod('freelancer_services_second_color');

	if($freelancer_services_second_color != false){
		$freelancer_services_custom_css .='.getstarted-btn a:hover, .view-all-btn a,.more-btn a,#comments input[type="submit"],#comments a.comment-reply-link,input[type="submit"],.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,nav.woocommerce-MyAccount-navigation ul li,.pro-button a, .woocommerce a.added_to_cart.wc-forward, #footer .wp-block-search .wp-block-search__button, #sidebar .wp-block-search .wp-block-search__button, #sidebar h3, .woocommerce span.onsale, .toggle-nav button, .bradcrumbs a:hover, .bradcrumbs span, nav.navigation.posts-navigation .nav-previous a, nav.navigation.posts-navigation .nav-next a, .wp-block-tag-cloud a:hover, #sidebar label.wp-block-search__label, #sidebar .wp-block-heading,.woocommerce nav.woocommerce-pagination ul li span.current, .woocommerce nav.woocommerce-pagination ul li a:hover{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_second_color).';';
		$freelancer_services_custom_css .='}';
	}

	if($freelancer_services_second_color != false){
		$freelancer_services_custom_css .='a, .copyright a:hover, .post-main-box:hover h2 a, #footer .textwidget a,#footer li a:hover,.post-main-box:hover h3 a,#sidebar ul li a:hover,.post-navigation a:hover .post-title, .post-navigation a:focus .post-title,.post-navigation a:hover,.post-navigation a:focus{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_second_color).';';
		$freelancer_services_custom_css .='}';
	}

	/*---------------------------Width Layout -------------------*/

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_width_option','Full Width');
    if($freelancer_services_theme_lay == 'Boxed'){
		$freelancer_services_custom_css .='body{';
			$freelancer_services_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_theme_lay == 'Wide Width'){
		$freelancer_services_custom_css .='body{';
			$freelancer_services_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_theme_lay == 'Full Width'){
		$freelancer_services_custom_css .='body{';
			$freelancer_services_custom_css .='max-width: 100%;';
		$freelancer_services_custom_css .='}';
	}

	/*--------------------------- Slider Opacity -------------------*/

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_slider_opacity_color','0.7');
	if($freelancer_services_theme_lay == '0'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.1'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.1';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.2'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.2';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.3'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.3';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.4'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.4';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.5'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.5';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.6'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.6';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.7'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.7';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.8'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.8';
		$freelancer_services_custom_css .='}';
		}else if($freelancer_services_theme_lay == '0.9'){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:0.9';
		$freelancer_services_custom_css .='}';
	}


	/*---------------------- Slider Image Overlay ------------------------*/

	$freelancer_services_slider_image_overlay = get_theme_mod('freelancer_services_slider_image_overlay', true);
	if($freelancer_services_slider_image_overlay == false){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='opacity:1;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_slider_image_overlay_color = get_theme_mod('freelancer_services_slider_image_overlay_color', true);
	if($freelancer_services_slider_image_overlay_color != false){
		$freelancer_services_custom_css .='#slider{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_slider_image_overlay_color).';';
		$freelancer_services_custom_css .='}';
	}

	/*---------------------------Slider Content Layout -------------------*/

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_slider_content_option','Left');
    if($freelancer_services_theme_lay == 'Left'){
		$freelancer_services_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='left:10%; right:45%; text-align:left;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='@media screen and (min-width: 720px) and (max-width:768px){
		#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='right:30%;';
		$freelancer_services_custom_css .='} }';
		$freelancer_services_custom_css .='@media screen and (max-width:720px){
		#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='left:15%; right: 15%';
		$freelancer_services_custom_css .='} }';
	}else if($freelancer_services_theme_lay == 'Center'){
		$freelancer_services_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='text-align:center; left:30%; right:30%;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_theme_lay == 'Right'){
		$freelancer_services_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='left: 45%; right: 10%; text-align: right;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='@media screen and (min-width: 720px) and (max-width:768px){
		#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='left:30%;';
		$freelancer_services_custom_css .='} }';
		$freelancer_services_custom_css .='@media screen and (max-width:720px){
		#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$freelancer_services_custom_css .='left:15%; right: 15%';
		$freelancer_services_custom_css .='} }';
	}

	/*------------------ Slider Height ------------*/
	$freelancer_services_slider_height = get_theme_mod('freelancer_services_slider_height');
	if($freelancer_services_slider_height != false){
		$freelancer_services_custom_css .='#slider img{';
			$freelancer_services_custom_css .='height: '.esc_attr($freelancer_services_slider_height).';';
		$freelancer_services_custom_css .='}';
	}

	/*------------- Slider ------------*/

	// $freelancer_services_slider = get_theme_mod('freelancer_services_slider_hide_show', false);
	// if($freelancer_services_slider == false){
	// 	$freelancer_services_custom_css .='.page-template-custom-home-page .main-header{';
	// 		$freelancer_services_custom_css .='position: static;';
	// 	$freelancer_services_custom_css .='}';
	// }

	/*----------------Responsive Media -----------------------*/

	$freelancer_services_resp_stickyheader = get_theme_mod( 'freelancer_services_stickyheader_hide_show',false);
	if($freelancer_services_resp_stickyheader == true && get_theme_mod( 'freelancer_services_sticky_header',false) != true){
    	$freelancer_services_custom_css .='.header-fixed{';
			$freelancer_services_custom_css .='position:static;';
		$freelancer_services_custom_css .='} ';
	}
    if($freelancer_services_resp_stickyheader == true){
    	$freelancer_services_custom_css .='@media screen and (max-width:575px) {';
		$freelancer_services_custom_css .='.header-fixed{';
			$freelancer_services_custom_css .='position:fixed;';
		$freelancer_services_custom_css .='} }';
	}else if($freelancer_services_resp_stickyheader == false){
		$freelancer_services_custom_css .='@media screen and (max-width:575px){';
		$freelancer_services_custom_css .='.header-fixed{';
			$freelancer_services_custom_css .='position:static;';
		$freelancer_services_custom_css .='} }';
	}

	$freelancer_services_resp_slider = get_theme_mod( 'freelancer_services_resp_slider_hide_show',true);
	if($freelancer_services_resp_slider == true && get_theme_mod( 'freelancer_services_slider_hide_show', true) == false){
    	$freelancer_services_custom_css .='#slider{';
			$freelancer_services_custom_css .='display:none;';
		$freelancer_services_custom_css .='} ';
	}
    if($freelancer_services_resp_slider == true){
    	$freelancer_services_custom_css .='@media screen and (max-width:575px) {';
		$freelancer_services_custom_css .='#slider{';
			$freelancer_services_custom_css .='display:block;';
		$freelancer_services_custom_css .='} }';
	}else if($freelancer_services_resp_slider == false){
		$freelancer_services_custom_css .='@media screen and (max-width:575px) {';
		$freelancer_services_custom_css .='#slider{';
			$freelancer_services_custom_css .='display:none;';
		$freelancer_services_custom_css .='} }';
		$freelancer_services_custom_css .='@media screen and (max-width:575px){';
		$freelancer_services_custom_css .='.page-template-custom-home-page.admin-bar .homepageheader{';
			$freelancer_services_custom_css .='margin-top: 45px;';
		$freelancer_services_custom_css .='} }';
	}

	$freelancer_services_resp_sidebar = get_theme_mod( 'freelancer_services_sidebar_hide_show',true);
    if($freelancer_services_resp_sidebar == true){
    	$freelancer_services_custom_css .='@media screen and (max-width:575px) {';
		$freelancer_services_custom_css .='#sidebar{';
			$freelancer_services_custom_css .='display:block;';
		$freelancer_services_custom_css .='} }';
	}else if($freelancer_services_resp_sidebar == false){
		$freelancer_services_custom_css .='@media screen and (max-width:575px) {';
		$freelancer_services_custom_css .='#sidebar{';
			$freelancer_services_custom_css .='display:none;';
		$freelancer_services_custom_css .='} }';
	}

	$freelancer_services_resp_scroll_top = get_theme_mod( 'freelancer_services_resp_scroll_top_hide_show',true);
	if($freelancer_services_resp_scroll_top == true && get_theme_mod( 'freelancer_services_hide_show_scroll',true) == false){
    	$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='visibility:hidden !important;';
		$freelancer_services_custom_css .='} ';
	}
    if($freelancer_services_resp_scroll_top == true){
    	$freelancer_services_custom_css .='@media screen and (max-width:575px) {';
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='visibility:visible !important;';
		$freelancer_services_custom_css .='} }';
	}else if($freelancer_services_resp_scroll_top == false){
		$freelancer_services_custom_css .='@media screen and (max-width:575px){';
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='visibility:hidden !important;';
		$freelancer_services_custom_css .='} }';
	}

	$freelancer_services_resp_menu_toggle_btn_bg_color = get_theme_mod('freelancer_services_resp_menu_toggle_btn_bg_color');
	if($freelancer_services_resp_menu_toggle_btn_bg_color != false){
		$freelancer_services_custom_css .='.toggle-nav button,.sidenav .closebtn{';
			$freelancer_services_custom_css .='background: '.esc_attr($freelancer_services_resp_menu_toggle_btn_bg_color).';';
		$freelancer_services_custom_css .='}';
	}
	
	/*---------------- Button Settings ------------------*/

	$freelancer_services_button_border_radius = get_theme_mod('freelancer_services_button_border_radius');
	if($freelancer_services_button_border_radius != false){
		$freelancer_services_custom_css .='.post-main-box .more-btn a{';
			$freelancer_services_custom_css .='border-radius: '.esc_attr($freelancer_services_button_border_radius).'px;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_button_padding_top_bottom = get_theme_mod('freelancer_services_button_padding_top_bottom');
	$freelancer_services_button_padding_left_right = get_theme_mod('freelancer_services_button_padding_left_right');
	if($freelancer_services_button_padding_top_bottom != false || $freelancer_services_button_padding_left_right != false){
		$freelancer_services_custom_css .='.post-main-box .more-btn a{';
			$freelancer_services_custom_css .='padding-top: '.esc_attr($freelancer_services_button_padding_top_bottom).'!important; padding-bottom: '.esc_attr($freelancer_services_button_padding_top_bottom).'!important;padding-left: '.esc_attr($freelancer_services_button_padding_left_right).'!important;padding-right: '.esc_attr($freelancer_services_button_padding_left_right).'!important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_button_font_size = get_theme_mod('freelancer_services_button_font_size',14);
	$freelancer_services_custom_css .='.post-main-box .more-btn a{';
		$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_button_font_size).';';
	$freelancer_services_custom_css .='}';

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_button_text_transform','Uppercase');
	if($freelancer_services_theme_lay == 'Capitalize'){
		$freelancer_services_custom_css .='.post-main-box .more-btn a{';
			$freelancer_services_custom_css .='text-transform:Capitalize;';
		$freelancer_services_custom_css .='}';
	}
	if($freelancer_services_theme_lay == 'Lowercase'){
		$freelancer_services_custom_css .='.post-main-box .more-btn a{';
			$freelancer_services_custom_css .='text-transform:Lowercase;';
		$freelancer_services_custom_css .='}';
	}
	if($freelancer_services_theme_lay == 'Uppercase'){ 
		$freelancer_services_custom_css .='.post-main-box .more-btn a{';
			$freelancer_services_custom_css .='text-transform:Uppercase;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_button_letter_spacing = get_theme_mod('freelancer_services_button_letter_spacing',14);
	$freelancer_services_custom_css .='.post-main-box .more-btn a{';
		$freelancer_services_custom_css .='letter-spacing: '.esc_attr($freelancer_services_button_letter_spacing).';';
	$freelancer_services_custom_css .='}';
 
	/*---------------- Single Post Settings ------------------*/

	$freelancer_services_single_blog_comment_title = get_theme_mod('freelancer_services_single_blog_comment_title', 'Leave a Reply');
	if($freelancer_services_single_blog_comment_title == ''){
		$freelancer_services_custom_css .='#comments h2#reply-title {';
			$freelancer_services_custom_css .='display: none;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_single_blog_comment_button_text = get_theme_mod('freelancer_services_single_blog_comment_button_text', 'Post Comment');
	if($freelancer_services_single_blog_comment_button_text == ''){
		$freelancer_services_custom_css .='#comments p.form-submit {';
			$freelancer_services_custom_css .='display: none;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_comment_width = get_theme_mod('freelancer_services_single_blog_comment_width');
	if($freelancer_services_comment_width != false){
		$freelancer_services_custom_css .='#comments textarea{';
			$freelancer_services_custom_css .='width: '.esc_attr($freelancer_services_comment_width).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_single_blog_post_navigation_show_hide = get_theme_mod('freelancer_services_single_blog_post_navigation_show_hide',true);
	if($freelancer_services_single_blog_post_navigation_show_hide != true){
		$freelancer_services_custom_css .='.post-navigation{';
			$freelancer_services_custom_css .='display: none;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_singlepost_image_box_shadow = get_theme_mod('freelancer_services_singlepost_image_box_shadow',0);
	if($freelancer_services_singlepost_image_box_shadow != false){
		$freelancer_services_custom_css .='.feature-box img{';
			$freelancer_services_custom_css .='box-shadow: '.esc_attr($freelancer_services_singlepost_image_box_shadow).'px '.esc_attr($freelancer_services_singlepost_image_box_shadow).'px '.esc_attr($freelancer_services_singlepost_image_box_shadow).'px #cccccc;';
		$freelancer_services_custom_css .='}';
	}

	/*---------------------------Blog Layout -------------------*/

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_blog_layout_option','Default');
    if($freelancer_services_theme_lay == 'Default'){
		$freelancer_services_custom_css .='.post-main-box{';
			$freelancer_services_custom_css .='';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_theme_lay == 'Center'){
		$freelancer_services_custom_css .='.post-main-box, .post-main-box h2, .post-info, .new-text p, .content-bttn{';
			$freelancer_services_custom_css .='text-align:center;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='.post-info{';
			$freelancer_services_custom_css .='margin-top:10px;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='.post-info hr{';
			$freelancer_services_custom_css .='margin:15px auto;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_theme_lay == 'Left'){
		$freelancer_services_custom_css .='.post-main-box, .post-main-box h2, .post-info, .new-text p, .content-bttn, #our-services p{';
			$freelancer_services_custom_css .='text-align:Left;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='.post-info hr{';
			$freelancer_services_custom_css .='margin-bottom:10px;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='.post-main-box h2{';
			$freelancer_services_custom_css .='margin-top:10px;';
		$freelancer_services_custom_css .='}';
	}

	/*--------------------- Blog Page Posts -------------------*/

	$freelancer_services_blog_page_posts_settings = get_theme_mod( 'freelancer_services_blog_page_posts_settings','Into Blocks');
		if($freelancer_services_blog_page_posts_settings == 'Without Blocks'){
		$freelancer_services_custom_css .='.post-main-box{';
			$freelancer_services_custom_css .='box-shadow: none; border: none; margin:30px 0;';
		$freelancer_services_custom_css .='}';
	}

	/*--------------------- Grid Posts Posts -------------------*/

	$freelancer_services_display_grid_posts_settings = get_theme_mod( 'freelancer_services_display_grid_posts_settings','Into Blocks');
    if($freelancer_services_display_grid_posts_settings == 'Without Blocks'){
		$freelancer_services_custom_css .='.post-main-box{';
			$freelancer_services_custom_css .='box-shadow: none; border: none; margin:30px 0;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_grid_featured_image_border_radius = get_theme_mod('freelancer_services_grid_featured_image_border_radius', 0);
	if($freelancer_services_grid_featured_image_border_radius != false){
		$freelancer_services_custom_css .='.grid-post-main-box .box-image img, .grid-post-main-box .feature-box img{';
			$freelancer_services_custom_css .='border-radius: '.esc_attr($freelancer_services_grid_featured_image_border_radius).'px;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_grid_featured_image_box_shadow = get_theme_mod('freelancer_services_grid_featured_image_box_shadow',0);
	if($freelancer_services_grid_featured_image_box_shadow != false){
		$freelancer_services_custom_css .='.grid-post-main-box .box-image img, .grid-post-main-box .feature-box img, #content-vw img{';
			$freelancer_services_custom_css .='box-shadow: '.esc_attr($freelancer_services_grid_featured_image_box_shadow).'px '.esc_attr($freelancer_services_grid_featured_image_box_shadow).'px '.esc_attr($freelancer_services_grid_featured_image_box_shadow).'px #cccccc;';
		$freelancer_services_custom_css .='}';
	}

	/*-------------- Copyright Alignment ----------------*/

	$freelancer_services_copyright_background_color = get_theme_mod('freelancer_services_copyright_background_color');
	if($freelancer_services_copyright_background_color != false){
		$freelancer_services_custom_css .='#footer-2{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_copyright_background_color).';';
		$freelancer_services_custom_css .='}';
	} 

	$freelancer_services_footer_widgets_heading = get_theme_mod( 'freelancer_services_footer_widgets_heading','Left');
    if($freelancer_services_footer_widgets_heading == 'Left'){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
		$freelancer_services_custom_css .='text-align: left;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_footer_widgets_heading == 'Center'){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$freelancer_services_custom_css .='text-align: center;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_footer_widgets_heading == 'Right'){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$freelancer_services_custom_css .='text-align: right;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_widgets_content = get_theme_mod( 'freelancer_services_footer_widgets_content','Left');
    if($freelancer_services_footer_widgets_content == 'Left'){
		$freelancer_services_custom_css .='#footer .widget{';
		$freelancer_services_custom_css .='text-align: left;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_footer_widgets_content == 'Center'){
		$freelancer_services_custom_css .='#footer .widget{';
			$freelancer_services_custom_css .='text-align: center;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_footer_widgets_content == 'Right'){
		$freelancer_services_custom_css .='#footer .widget{';
			$freelancer_services_custom_css .='text-align: right;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_copyright_alingment = get_theme_mod('freelancer_services_copyright_alingment');
	if($freelancer_services_copyright_alingment != false){
		$freelancer_services_custom_css .='.copyright p, #footer-2 p{';
			$freelancer_services_custom_css .='text-align: '.esc_attr($freelancer_services_copyright_alingment).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_nav_menus_font_weight = get_theme_mod( 'freelancer_services_navigation_menu_font_weight','Default');
    if($freelancer_services_nav_menus_font_weight == 'Default'){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_nav_menus_font_weight == 'Normal'){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='font-weight: normal;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_padding = get_theme_mod('freelancer_services_footer_padding');
	if($freelancer_services_footer_padding != false){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='padding: '.esc_attr($freelancer_services_footer_padding).' 0;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_icon = get_theme_mod('freelancer_services_footer_icon');
	if($freelancer_services_footer_icon == false){
		$freelancer_services_custom_css .='.copyright p{';
			$freelancer_services_custom_css .='width:100%; text-align:center; float:none;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_background_image = get_theme_mod('freelancer_services_footer_background_image');
	if($freelancer_services_footer_background_image != false){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background: url('.esc_attr($freelancer_services_footer_background_image).')background-size:cover;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_background_color = get_theme_mod('freelancer_services_footer_background_color');
	if($freelancer_services_footer_background_color != false){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_footer_background_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_navigation_menu_font_size = get_theme_mod('freelancer_services_navigation_menu_font_size');
	if($freelancer_services_navigation_menu_font_size != false){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_navigation_menu_font_size).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_navigation_menu_font_weight = get_theme_mod('freelancer_services_navigation_menu_font_weight','500');
	if($freelancer_services_navigation_menu_font_weight != false){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='font-weight: '.esc_attr($freelancer_services_navigation_menu_font_weight).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_menu_text_transform','Capitalize');
	if($freelancer_services_theme_lay == 'Capitalize'){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='text-transform:Capitalize;';
		$freelancer_services_custom_css .='}';
	}
	if($freelancer_services_theme_lay == 'Lowercase'){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='text-transform:Lowercase;';
		$freelancer_services_custom_css .='}';
	}
	if($freelancer_services_theme_lay == 'Uppercase'){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='text-transform:Uppercase;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_img_footer','scroll');
	if($freelancer_services_theme_lay == 'fixed'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background-attachment: fixed !important;';
		$freelancer_services_custom_css .='}';
	}elseif ($freelancer_services_theme_lay == 'scroll'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background-attachment: scroll !important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_img_position = get_theme_mod('freelancer_services_footer_img_position','center center');
	if($freelancer_services_footer_img_position != false){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background-position: '.esc_attr($freelancer_services_footer_img_position).'!important;';
		$freelancer_services_custom_css .='}';
	} 

	$freelancer_services_copyright_font_size = get_theme_mod('freelancer_services_copyright_font_size');
	if($freelancer_services_copyright_font_size != false){
		$freelancer_services_custom_css .='.copyright p, .copyright a{';
			$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_copyright_font_size).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_copyright_font_weight = get_theme_mod('freelancer_services_copyright_font_weight');
	if($freelancer_services_copyright_font_weight != false){
		$freelancer_services_custom_css .='.copyright p, .copyright a{';
			$freelancer_services_custom_css .='font-weight: '.esc_attr($freelancer_services_copyright_font_weight).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_copyright_text_color = get_theme_mod('freelancer_services_copyright_text_color');
	if($freelancer_services_copyright_text_color != false){
		$freelancer_services_custom_css .='.copyright p, .copyright a{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_copyright_text_color).';';
		$freelancer_services_custom_css .='}';
	} 

	/*------------------ Woocommerce settings  -------------------*/

	$freelancer_services_related_product_show_hide = get_theme_mod('freelancer_services_related_product_show_hide',true);
	if($freelancer_services_related_product_show_hide != true){
		$freelancer_services_custom_css .='.related.products{';
			$freelancer_services_custom_css .='display: none;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_products_btn_padding_top_bottom = get_theme_mod('freelancer_services_products_btn_padding_top_bottom');
	if($freelancer_services_products_btn_padding_top_bottom != false){
		$freelancer_services_custom_css .='.woocommerce a.button{';
			$freelancer_services_custom_css .='padding-top: '.esc_attr($freelancer_services_products_btn_padding_top_bottom).' !important; padding-bottom: '.esc_attr($freelancer_services_products_btn_padding_top_bottom).' !important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_products_btn_padding_left_right = get_theme_mod('freelancer_services_products_btn_padding_left_right');
	if($freelancer_services_products_btn_padding_left_right != false){
		$freelancer_services_custom_css .='.woocommerce a.button{';
			$freelancer_services_custom_css .='padding-left: '.esc_attr($freelancer_services_products_btn_padding_left_right).' !important; padding-right: '.esc_attr($freelancer_services_products_btn_padding_left_right).' !important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_products_button_border_radius = get_theme_mod('freelancer_services_products_button_border_radius', 30);
	if($freelancer_services_products_button_border_radius != false){
		$freelancer_services_custom_css .='.woocommerce ul.products li.product .button, a.checkout-button.button.alt.wc-forward,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt{';
			$freelancer_services_custom_css .='border-radius: '.esc_attr($freelancer_services_products_button_border_radius).'px;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_woocommerce_sale_position = get_theme_mod( 'freelancer_services_woocommerce_sale_position','left');
    if($freelancer_services_woocommerce_sale_position == 'left'){
		$freelancer_services_custom_css .='.woocommerce ul.products li.product .onsale{';
			$freelancer_services_custom_css .='left: -10px; right: auto;';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_woocommerce_sale_position == 'right'){
		$freelancer_services_custom_css .='.woocommerce ul.products li.product .onsale{';
			$freelancer_services_custom_css .='left: auto !important; right: 15px !important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_woocommerce_sale_padding_top_bottom = get_theme_mod('freelancer_services_woocommerce_sale_padding_top_bottom');
	if($freelancer_services_woocommerce_sale_padding_top_bottom != false){
		$freelancer_services_custom_css .='.woocommerce span.onsale{';
			$freelancer_services_custom_css .='padding-top: '.esc_attr($freelancer_services_woocommerce_sale_padding_top_bottom).'; padding-bottom: '.esc_attr($freelancer_services_woocommerce_sale_padding_top_bottom).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_woocommerce_sale_padding_left_right = get_theme_mod('freelancer_services_woocommerce_sale_padding_left_right');
	if($freelancer_services_woocommerce_sale_padding_left_right != false){
		$freelancer_services_custom_css .='.woocommerce span.onsale{';
			$freelancer_services_custom_css .='padding-left: '.esc_attr($freelancer_services_woocommerce_sale_padding_left_right).'; padding-right: '.esc_attr($freelancer_services_woocommerce_sale_padding_left_right).';';
		$freelancer_services_custom_css .='}';
	}

	// featured image dimention
	$freelancer_services_blog_post_featured_image_dimension = get_theme_mod('freelancer_services_blog_post_featured_image_dimension', 'default');
	$freelancer_services_blog_post_featured_image_custom_width = get_theme_mod('freelancer_services_blog_post_featured_image_custom_width',250);
	$freelancer_services_blog_post_featured_image_custom_height = get_theme_mod('freelancer_services_blog_post_featured_image_custom_height',250);
	if($freelancer_services_blog_post_featured_image_dimension == 'custom'){
		$freelancer_services_custom_css .='.post-main-box img{';
			$freelancer_services_custom_css .='width: '.esc_attr($freelancer_services_blog_post_featured_image_custom_width).'; height: '.esc_attr($freelancer_services_blog_post_featured_image_custom_height).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_featured_image_border_radius = get_theme_mod('freelancer_services_featured_image_border_radius', 0);
	if($freelancer_services_featured_image_border_radius != false){
		$freelancer_services_custom_css .='.box-image img, .feature-box img{';
			$freelancer_services_custom_css .='border-radius: '.esc_attr($freelancer_services_featured_image_border_radius).'px;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_featured_image_box_shadow = get_theme_mod('freelancer_services_featured_image_box_shadow',0);
	if($freelancer_services_featured_image_box_shadow != false){
		$freelancer_services_custom_css .='.box-image img, #content-vw img{';
			$freelancer_services_custom_css .='box-shadow: '.esc_attr($freelancer_services_featured_image_box_shadow).'px '.esc_attr($freelancer_services_featured_image_box_shadow).'px '.esc_attr($freelancer_services_featured_image_box_shadow).'px #cccccc;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_related_image_box_shadow = get_theme_mod('freelancer_services_related_image_box_shadow',0);
	if($freelancer_services_related_image_box_shadow != false){
		$freelancer_services_custom_css .='.related-post .box-image img{';
			$freelancer_services_custom_css .='box-shadow: '.esc_attr($freelancer_services_related_image_box_shadow).'px '.esc_attr($freelancer_services_related_image_box_shadow).'px '.esc_attr($freelancer_services_related_image_box_shadow).'px #cccccc;';
		$freelancer_services_custom_css .='}';
	}
	/*------------------ Logo  -------------------*/

	$freelancer_services_logo_padding = get_theme_mod('freelancer_services_logo_padding');
	if($freelancer_services_logo_padding != false){
		$freelancer_services_custom_css .='.main-header .logo{';
			$freelancer_services_custom_css .='padding: '.esc_attr($freelancer_services_logo_padding).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_logo_margin = get_theme_mod('freelancer_services_logo_margin');
	if($freelancer_services_logo_margin != false){
		$freelancer_services_custom_css .='.main-header .logo{';
			$freelancer_services_custom_css .='margin: '.esc_attr($freelancer_services_logo_margin).';';
		$freelancer_services_custom_css .='}';
	}

	// Site title Font Size
	$freelancer_services_site_title_font_size = get_theme_mod('freelancer_services_site_title_font_size');
	if($freelancer_services_site_title_font_size != false){
		$freelancer_services_custom_css .='.logo h1, .logo p.site-title{';
			$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_site_title_font_size).';';
		$freelancer_services_custom_css .='}';
	}

	// Site tagline Font Size
	$freelancer_services_site_tagline_font_size = get_theme_mod('freelancer_services_site_tagline_font_size');
	if($freelancer_services_site_tagline_font_size != false){
		$freelancer_services_custom_css .='.logo p.site-description{';
			$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_site_tagline_font_size).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_site_title_color = get_theme_mod('freelancer_services_site_title_color');
	if($freelancer_services_site_title_color != false){
		$freelancer_services_custom_css .='p.site-title a{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_site_title_color).'!important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_site_tagline_color = get_theme_mod('freelancer_services_site_tagline_color');
	if($freelancer_services_site_tagline_color != false){
		$freelancer_services_custom_css .='.logo p.site-description{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_site_tagline_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_logo_width = get_theme_mod('freelancer_services_logo_width');
	if($freelancer_services_logo_width != false){
		$freelancer_services_custom_css .='.logo img{';
			$freelancer_services_custom_css .='width: '.esc_attr($freelancer_services_logo_width).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_logo_height = get_theme_mod('freelancer_services_logo_height');
	if($freelancer_services_logo_height != false){
		$freelancer_services_custom_css .='.logo img{';
			$freelancer_services_custom_css .='height: '.esc_attr($freelancer_services_logo_height).';';
		$freelancer_services_custom_css .='}';
	}

	// Woocommerce img

	$freelancer_services_shop_featured_image_border_radius = get_theme_mod('freelancer_services_shop_featured_image_border_radius', 0);
	if($freelancer_services_shop_featured_image_border_radius != false){
		$freelancer_services_custom_css .='.woocommerce ul.products li.product a img{';
			$freelancer_services_custom_css .='border-radius: '.esc_attr($freelancer_services_shop_featured_image_border_radius).'px;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_shop_featured_image_box_shadow = get_theme_mod('freelancer_services_shop_featured_image_box_shadow');
	if($freelancer_services_shop_featured_image_box_shadow != false){
		$freelancer_services_custom_css .='.woocommerce ul.products li.product a img{';
				$freelancer_services_custom_css .='box-shadow: '.esc_attr($freelancer_services_shop_featured_image_box_shadow).'px '.esc_attr($freelancer_services_shop_featured_image_box_shadow).'px '.esc_attr($freelancer_services_shop_featured_image_box_shadow).'px #ddd;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_header_menus_color = get_theme_mod('freelancer_services_header_menus_color');
	if($freelancer_services_header_menus_color != false){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_header_menus_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_header_menus_hover_color = get_theme_mod('freelancer_services_header_menus_hover_color');
	if($freelancer_services_header_menus_hover_color != false){
		$freelancer_services_custom_css .='.main-navigation a:hover{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_header_menus_hover_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_header_submenus_color = get_theme_mod('freelancer_services_header_submenus_color');
	if($freelancer_services_header_submenus_color != false){
		$freelancer_services_custom_css .='.main-navigation ul ul a{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_header_submenus_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_header_submenus_hover_color = get_theme_mod('freelancer_services_header_submenus_hover_color');
	if($freelancer_services_header_submenus_hover_color != false){
		$freelancer_services_custom_css .='.main-navigation ul.sub-menu a:hover{';
			$freelancer_services_custom_css .='color: '.esc_attr($freelancer_services_header_submenus_hover_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_menus_item = get_theme_mod( 'freelancer_services_menus_item_style','None');
    if($freelancer_services_menus_item == 'None'){
		$freelancer_services_custom_css .='.main-navigation a{';
			$freelancer_services_custom_css .='';
		$freelancer_services_custom_css .='}';
	}else if($freelancer_services_menus_item == 'Zoom In'){
		$freelancer_services_custom_css .='.main-navigation a:hover{';
			$freelancer_services_custom_css .='transition: all 0.3s ease-in-out !important; transform: scale(1.2) !important; color: #6102d3;';
		$freelancer_services_custom_css .='}';
	}

	/*--------------- Preloader Background Color  -------------------*/

	$freelancer_services_preloader_bg_color = get_theme_mod('freelancer_services_preloader_bg_color');
	if($freelancer_services_preloader_bg_color != false){
		$freelancer_services_custom_css .='#preloader{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_preloader_bg_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_preloader_border_color = get_theme_mod('freelancer_services_preloader_border_color');
	if($freelancer_services_preloader_border_color != false){
		$freelancer_services_custom_css .='.loader-line{';
			$freelancer_services_custom_css .='border-color: '.esc_attr($freelancer_services_preloader_border_color).'!important;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_preloader_bg_img = get_theme_mod('freelancer_services_preloader_bg_img');
	if($freelancer_services_preloader_bg_img != false){
		$freelancer_services_custom_css .='#preloader{';
			$freelancer_services_custom_css .='background: url('.esc_attr($freelancer_services_preloader_bg_img).');-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;';
		$freelancer_services_custom_css .='}';
	}

	// Header Background Color
	$freelancer_services_header_background_color = get_theme_mod('freelancer_services_header_background_color');
	if($freelancer_services_header_background_color != false){
		$freelancer_services_custom_css .='.home-page-header{';
			$freelancer_services_custom_css .='background-color: '.esc_attr($freelancer_services_header_background_color).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_header_img_position = get_theme_mod('freelancer_services_header_img_position','center top');
	if($freelancer_services_header_img_position != false){
		$freelancer_services_custom_css .='.home-page-header{';
			$freelancer_services_custom_css .='background-position: '.esc_attr($freelancer_services_header_img_position).'!important;';
		$freelancer_services_custom_css .='}';
	}

	/*----------------Sroll to top Settings ------------------*/

	$freelancer_services_scroll_to_top_font_size = get_theme_mod('freelancer_services_scroll_to_top_font_size');
	if($freelancer_services_scroll_to_top_font_size != false){
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_scroll_to_top_font_size).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_scroll_to_top_padding = get_theme_mod('freelancer_services_scroll_to_top_padding');
	$freelancer_services_scroll_to_top_padding = get_theme_mod('freelancer_services_scroll_to_top_padding');
	if($freelancer_services_scroll_to_top_padding != false){
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='padding-top: '.esc_attr($freelancer_services_scroll_to_top_padding).';padding-bottom: '.esc_attr($freelancer_services_scroll_to_top_padding).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_scroll_to_top_width = get_theme_mod('freelancer_services_scroll_to_top_width');
	if($freelancer_services_scroll_to_top_width != false){
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='width: '.esc_attr($freelancer_services_scroll_to_top_width).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_scroll_to_top_height = get_theme_mod('freelancer_services_scroll_to_top_height');
	if($freelancer_services_scroll_to_top_height != false){
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='height: '.esc_attr($freelancer_services_scroll_to_top_height).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_scroll_to_top_border_radius = get_theme_mod('freelancer_services_scroll_to_top_border_radius');
	if($freelancer_services_scroll_to_top_border_radius != false){
		$freelancer_services_custom_css .='.scrollup i{';
			$freelancer_services_custom_css .='border-radius: '.esc_attr($freelancer_services_scroll_to_top_border_radius).'px;';
		$freelancer_services_custom_css .='}';
	}

	/*----------------Social Icons Settings ------------------*/

	$freelancer_services_social_icon_font_size = get_theme_mod('freelancer_services_social_icon_font_size');
	if($freelancer_services_social_icon_font_size != false){
		$freelancer_services_custom_css .='#sidebar .custom-social-icons i, #footer-2 .custom-social-icons i{';
			$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_social_icon_font_size).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_social_icon_padding = get_theme_mod('freelancer_services_social_icon_padding');
	if($freelancer_services_social_icon_padding != false){
		$freelancer_services_custom_css .='#sidebar .custom-social-icons i, #footer-2 .custom-social-icons i{';
			$freelancer_services_custom_css .='padding: '.esc_attr($freelancer_services_social_icon_padding).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_social_icon_width = get_theme_mod('freelancer_services_social_icon_width');
	if($freelancer_services_social_icon_width != false){
		$freelancer_services_custom_css .='#sidebar .custom-social-icons i, #footer-2 .custom-social-icons i{';
			$freelancer_services_custom_css .='width: '.esc_attr($freelancer_services_social_icon_width).';';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_social_icon_height = get_theme_mod('freelancer_services_social_icon_height');
	if($freelancer_services_social_icon_height != false){
		$freelancer_services_custom_css .='#sidebar .custom-social-icons i, #footer-2 .custom-social-icons i{';
			$freelancer_services_custom_css .='height: '.esc_attr($freelancer_services_social_icon_height).';';
		$freelancer_services_custom_css .='}';
	}

	/*---------------- Footer Settings ------------------*/

	$freelancer_services_button_footer_heading_letter_spacing = get_theme_mod('freelancer_services_button_footer_heading_letter_spacing',1);
	$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label, a.rsswidget.rss-widget-title{';
		$freelancer_services_custom_css .='letter-spacing: '.esc_attr($freelancer_services_button_footer_heading_letter_spacing).'px;';
	$freelancer_services_custom_css .='}';

	$freelancer_services_button_footer_font_size = get_theme_mod('freelancer_services_button_footer_font_size','25');
	$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label, a.rsswidget.rss-widget-title{';
		$freelancer_services_custom_css .='font-size: '.esc_attr($freelancer_services_button_footer_font_size).'px;';
	$freelancer_services_custom_css .='}';

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_button_footer_text_transform','Capitalize');
	if($freelancer_services_theme_lay == 'Capitalize'){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$freelancer_services_custom_css .='text-transform:Capitalize;';
		$freelancer_services_custom_css .='}';
	}
	if($freelancer_services_theme_lay == 'Lowercase'){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label, a.rsswidget.rss-widget-title{';
			$freelancer_services_custom_css .='text-transform:Lowercase;';
		$freelancer_services_custom_css .='}';
	}
	if($freelancer_services_theme_lay == 'Uppercase'){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label, a.rsswidget.rss-widget-title{';
			$freelancer_services_custom_css .='text-transform:Uppercase;';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_footer_heading_weight = get_theme_mod('freelancer_services_footer_heading_weight','600');
	if($freelancer_services_footer_heading_weight != false){
		$freelancer_services_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label, a.rsswidget.rss-widget-title{';
			$freelancer_services_custom_css .='font-weight: '.esc_attr($freelancer_services_footer_heading_weight).';';
		$freelancer_services_custom_css .='}';
	}

	/*---------------------------Footer Style -------------------*/

	$freelancer_services_theme_lay = get_theme_mod( 'freelancer_services_footer_template','freelancer_services-footer-one');
    if($freelancer_services_theme_lay == 'freelancer_services-footer-one'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='';
		$freelancer_services_custom_css .='}';

	}else if($freelancer_services_theme_lay == 'freelancer_services-footer-two'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background: linear-gradient(to right, #f9f8ff, #dedafa);';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='#footer p, #footer li a, #footer, #footer h3, #footer a.rsswidget, #footer #wp-calendar a, .copyright a, #footer .custom_details, #footer ins span, #footer .tagcloud a, .main-inner-box span.entry-date a, nav.woocommerce-MyAccount-navigation ul li:hover a, #footer ul li a, #footer table, #footer th, #footer td, #footer caption, #sidebar caption,#footer nav.wp-calendar-nav a,#footer .search-form .search-field{';
			$freelancer_services_custom_css .='color:#000;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='#footer ul li::before{';
			$freelancer_services_custom_css .='background:#000;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='#footer table, #footer th, #footer td,#footer .search-form .search-field,#footer .tagcloud a{';
			$freelancer_services_custom_css .='border: 1px solid #000;';
		$freelancer_services_custom_css .='}';

	}else if($freelancer_services_theme_lay == 'freelancer_services-footer-three'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background: #232524;';
		$freelancer_services_custom_css .='}';
	}
	else if($freelancer_services_theme_lay == 'freelancer_services-footer-four'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background: #f7f7f7;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='#footer p, #footer li a, #footer, #footer h3, #footer a.rsswidget, #footer #wp-calendar a, .copyright a, #footer .custom_details, #footer ins span, #footer .tagcloud a, .main-inner-box span.entry-date a, nav.woocommerce-MyAccount-navigation ul li:hover a, #footer ul li a, #footer table, #footer th, #footer td, #footer caption, #sidebar caption,#footer nav.wp-calendar-nav a,#footer .search-form .search-field{';
			$freelancer_services_custom_css .='color:#000;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='#footer ul li::before{';
			$freelancer_services_custom_css .='background:#000;';
		$freelancer_services_custom_css .='}';
		$freelancer_services_custom_css .='#footer table, #footer th, #footer td,#footer .search-form .search-field,#footer .tagcloud a{';
			$freelancer_services_custom_css .='border: 1px solid #000;';
		$freelancer_services_custom_css .='}';
	}
	else if($freelancer_services_theme_lay == 'freelancer_services-footer-five'){
		$freelancer_services_custom_css .='#footer{';
			$freelancer_services_custom_css .='background: linear-gradient(to right, #01093a, #2d0b00);';
		$freelancer_services_custom_css .='}';
	}

	$freelancer_services_responsive_preloader_hide = get_theme_mod('freelancer_services_responsive_preloader_hide',false);
	if($freelancer_services_responsive_preloader_hide == true && get_theme_mod('freelancer_services_loader_enable',false) == false){
		$freelancer_services_custom_css .='@media screen and (min-width:575px){
			#preloader{';
			$freelancer_services_custom_css .='display:none !important;';
		$freelancer_services_custom_css .='} }';
	}

	if($freelancer_services_responsive_preloader_hide == false){
		$freelancer_services_custom_css .='@media screen and (max-width:575px){
			#preloader{';
			$freelancer_services_custom_css .='display:none !important;';
		$freelancer_services_custom_css .='} }';
	}

	$freelancer_services_bradcrumbs_alignment = get_theme_mod( 'freelancer_services_bradcrumbs_alignment','Left');
    if($freelancer_services_bradcrumbs_alignment == 'Left'){
    	$freelancer_services_custom_css .='@media screen and (min-width:768px) {';
		$freelancer_services_custom_css .='.bradcrumbs{';
			$freelancer_services_custom_css .='text-align:start;';
		$freelancer_services_custom_css .='}}';
	}else if($freelancer_services_bradcrumbs_alignment == 'Center'){
		$freelancer_services_custom_css .='@media screen and (min-width:768px) {';
		$freelancer_services_custom_css .='.bradcrumbs{';
			$freelancer_services_custom_css .='text-align:center;';
		$freelancer_services_custom_css .='}}';
	}else if($freelancer_services_bradcrumbs_alignment == 'Right'){
		$freelancer_services_custom_css .='@media screen and (min-width:768px) {';
		$freelancer_services_custom_css .='.bradcrumbs{';
			$freelancer_services_custom_css .='text-align:end;';
		$freelancer_services_custom_css .='}}';
	}